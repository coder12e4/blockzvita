import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:untitled1/home/home.dart';

class login extends StatefulWidget {
  const login({Key? key}) : super(key: key);

  @override
  _loginState createState() => _loginState();
}

class _loginState extends State<login> {
  TextEditingController UserNameController = TextEditingController();
  TextEditingController PassWordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: Colors.lightBlue,
        padding: EdgeInsets.all(30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "DIGITM",
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  overflow: TextOverflow.ellipsis),
            ),
            SizedBox(
              height: 100,
            ),
            TextField(
              controller: UserNameController,
              decoration: InputDecoration(
                  prefixIcon: Icon(
                Icons.access_alarm_sharp,
                color: Colors.white,
                size: 24,
              )),
            ),
            SizedBox(
              height: 20,
            ),
            TextField(
              controller: PassWordController,
              obscureText: true,
              decoration: InputDecoration(
                  prefixIcon: Icon(
                Icons.lock_sharp,
                color: Colors.white,
                size: 24,
              )),
            ),
            SizedBox(
              height: 20,
            ),
            FlatButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => home(
                              userName: UserNameController.text,
                              passWord: PassWordController.text,
                            )));
              },
              child: Container(
                width: 100,
                height: 50,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: Colors.blue),
                child: Row(
                  children: [
                    Icon(
                      Icons.lock_sharp,
                      color: Colors.white,
                    ),
                    Text("SignUp")
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
