import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class home extends StatefulWidget {
  //member variables
  final String userName;
  final String passWord;
  //constructor
  const home({Key? key, required this.userName, required this.passWord})
      : super(key: key);
  @override
  _homeState createState() => _homeState();
}

class _homeState extends State<home> {
  String? k;
  void accesingVariable() {
    k = widget.userName;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Arj Jish App"),
        centerTitle: true,
        backgroundColor: Colors.pinkAccent,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: Colors.orange,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.only(left: 20, top: 20, right: 0, bottom: 0),
              margin: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: 20),
              height: 60,
              width: 60,
              color: Colors.red,
              child: Text(widget.userName),
            ),
            Container(
              height: 60,
              width: 60,
              color: Colors.teal,
              child: Text(widget.passWord),
            ),
          ],
        ),
      ),
    );
  }
}
