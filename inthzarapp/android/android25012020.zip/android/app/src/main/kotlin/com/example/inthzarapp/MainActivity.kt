package com.example.inthzarapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
