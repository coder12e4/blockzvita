package com.coderacademy.cubit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
