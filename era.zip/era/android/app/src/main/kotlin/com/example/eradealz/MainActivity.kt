package com.example.eradealz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
