import 'dart:convert';

import 'package:eradealz/Model/FetchCatgry_Class.dart';
import 'package:eradealz/Screen/ProductDetails/productdetails.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';

class subcategory extends StatefulWidget {
  String Id, Name;
  subcategory({Key key, this.Id, this.Name});

  @override
  _subcategoryState createState() => _subcategoryState();
}
var refreshKey=GlobalKey<RefreshIndicatorState>();

class _subcategoryState extends State<subcategory> {
  Future<FetchCategoryApi> getdata() async {
    String url =
        "https://eradealz.com/api/category_fetch.php?" + "id" + "=" + widget.Id;

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Success");
      return FetchCategoryApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        elevation: 0.01,
        backgroundColor: Color(0xFFec1c24),
        centerTitle: false,
        title: Text(
          widget.Name,
          style: appBarStyle,
        ),
      ),
      body: RefreshIndicator(
        key: refreshKey,
        onRefresh: refreshList,
        child: ListView(
          shrinkWrap: true,
          physics: BouncingScrollPhysics(),
          children: [
            SizedBox(height: size.height * 0.02),
            FutureBuilder(
                future: getdata(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    List<Item> arr = snapshot.data.items;
                    return GridView.builder(
                        physics: BouncingScrollPhysics(),
                        itemCount: arr.length,
                        shrinkWrap: true,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          childAspectRatio: 0.7,
                          crossAxisCount: 2,
                          mainAxisSpacing: 10,
                          crossAxisSpacing: 5,
                        ),
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                CustomPageRoute(
                                  child: ProductDetails(
                                    pid: arr[index].id,
                                    oid: arr[index].offerId,
                                  ),
                                ),
                              );
                            },
                            child: Card(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(1),
                                child: Container(
                                  child: Column(
                                    children: [
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(1),
                                        child: Container(
                                          height: size.height * 0.24,
                                          width: size.width * 0.4,
                                          child: CachedNetworkImage(
                                            imageUrl: arr[index].photo.toString(),
                                            fit: BoxFit.fill,
                                            placeholder: (context, url) =>
                                                Shimmer.fromColors(
                                              baseColor: Colors.grey.shade200,
                                              highlightColor: Colors.grey.shade50,
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(1),
                                                  child: Container(
                                                    height: size.height * 0.24,
                                                    width: size.width * 0.4,
                                                    color: Colors.grey.shade100,
                                                  )),
                                            ),
                                            errorWidget: (context, url, error) =>
                                                Image.asset(
                                              "images/ina.jpg",
                                              fit: BoxFit.fill,
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(height: size.height * 0.009),
                                      Text(arr[index].name),
                                      SizedBox(height: size.height * 0.01),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          SizedBox(width: size.width * 0.04),
                                          Text(
                                            "INR " + arr[index].price,
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(17),
                                                color: Colors.teal.shade300),
                                            child: Center(
                                              child: Padding(
                                                padding: const EdgeInsets.all(5),
                                                child: Text(
                                                  arr[index].entries +
                                                      " Enteries",
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          )
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        });
                  } else {
                    return Column(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.35,
                        ),
                        Center(child: Loading()),
                      ],
                    );
                  }
                }),
          ],
        ),
      ),
    );
  }

  Future<void> refreshList() async{
    refreshKey.currentState.show(atTop: false);
    await Future.delayed(Duration(seconds: 2));
    setState(() {
      getdata();
    });
    return null;
  }

}
