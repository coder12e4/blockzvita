import 'dart:convert';
import 'package:eradealz/Model/EraContact_Class.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class EraContact extends StatefulWidget {
  const EraContact({Key key}) : super(key: key);

  @override
  _EraContactState createState() => _EraContactState();
}

class _EraContactState extends State<EraContact> {
  Future<ContactApi> getdata() async {
    String url = "https://eradealz.com/api/contact_us.php";

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Success");

      return ContactApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Container(
      child: FutureBuilder(
          future: getdata(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              List<Item> arr = snapshot.data.items;
              return ListView.builder(
                  itemCount: arr.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    return Container(
                      // contact details column
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              //Company Name
                              Container(
                                child: Text(
                                  arr[index].address,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: eraMainTextColor,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ),
                              SizedBox(height: size.height * 0.01),
                              Container(
                                child: Icon(
                                  FontAwesomeIcons.mapMarkerAlt,
                                  color: eraPrimaryColor,
                                  size: 15,
                                ),
                              ),
                              SizedBox(height: size.height * 0.01),
                              //street
                              Container(
                                child: Text(
                                  arr[index].street +
                                      ", " +
                                      arr[index].country +
                                      " - " +
                                      arr[index].postal,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: eraMainTextColor,
                                  ),
                                ),
                              ),
                              SizedBox(height: size.height * 0.01),
                              Container(
                                child: Icon(
                                  FontAwesomeIcons.solidEnvelope,
                                  color: eraPrimaryColor,
                                  size: 15,
                                ),
                              ),
                              SizedBox(height: size.height * 0.01),
                              //email
                              Container(
                                child: Text(
                                  arr[index].email,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: eraMainTextColor,
                                  ),
                                ),
                              ),
                              SizedBox(height: size.height * 0.01),
                              Container(
                                child: Icon(
                                  FontAwesomeIcons.phoneAlt,
                                  color: eraPrimaryColor,
                                  size: 15,
                                ),
                              ),
                              SizedBox(height: size.height * 0.01),
                              //mobile
                              Container(
                                child: Text(
                                  arr[index].phone,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: eraMainTextColor,
                                  ),
                                ),
                              ),
                              SizedBox(height: size.height * 0.01),
                              Container(
                                child: Icon(
                                  Icons.watch_later_rounded,
                                  color: eraPrimaryColor,
                                  size: 18
                                ),
                              ),
                              SizedBox(height: size.height * 0.01),
                              //working hours
                              Container(
                                child: Text(
                                  "Monday to Friday - 9am to 6pm",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: eraMainTextColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: size.height * 0.02),
                          Divider(),
                          SizedBox(height: size.height * 0.01),
                          //follow us on
                          Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                child: Text(
                                  "Follow us on",
                                  style: TextStyle(
                                    letterSpacing: 0.5,
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          //social media button icons
                          Container(
                            padding: EdgeInsets.symmetric(vertical: 10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                //fb
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    IconButton(
                                      icon: Icon(
                                        FontAwesomeIcons.facebookSquare,
                                        color: eraPrimaryColor,
                                        size: 24.0,
                                      ),
                                      onPressed: () {
                                        _launchURL('Facebook');
                                      },
                                    ),
                                    Text(
                                      "Facebook",
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: eraTextColor,
                                      ),
                                    ),
                                  ],
                                ),
                                //insta
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    IconButton(
                                      icon: Icon(
                                        FontAwesomeIcons.instagram,
                                        color: eraPrimaryColor,
                                        size: 24.0,
                                      ),
                                      onPressed: () {
                                        _launchURL('Instagram');
                                      },
                                    ),
                                    Text(
                                      "Instagram",
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: eraTextColor,
                                      ),
                                    ),
                                  ],
                                ),
                                //youtube
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    IconButton(
                                      icon: Icon(
                                        FontAwesomeIcons.youtube,
                                        color: eraPrimaryColor,
                                        size: 24.0,
                                      ),
                                      onPressed: () {
                                        _launchURL('Youtube');
                                      },
                                    ),
                                    Text(
                                      "YouTube",
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: eraTextColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  });
            } else {
              return Center(
                child: Loading(),
              );
            }
          }),
    );
  }
}

_launchURL(String value) async {
  const _fbURL = 'https://www.facebook.com/eradealzind/';
  const _instaURL = 'https://www.instagram.com/eradealz/';
  const _ytURL = 'https://youtube.com/channel/UCaY0blMOp45_iWdjkh7pR9A';

  if (value == 'Facebook') {
    if (await canLaunch(_fbURL)) {
      await launch(_fbURL);
    } else {
      throw 'Could not launch $_fbURL';
    }
  } else if (value == 'Instagram') {
    if (await canLaunch(_instaURL)) {
      await launch(_instaURL);
    } else {
      throw 'Could not launch $_instaURL';
    }
  } else if (value == 'Youtube') {
    if (await canLaunch(_ytURL)) {
      await launch(_ytURL);
    } else {
      throw 'Could not launch $_ytURL';
    }
  }
}
