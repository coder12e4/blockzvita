import 'package:eradealz/Model/Privacy_Class.dart';
import 'package:eradealz/Screen/Contact%20Us/contact_details.dart';
import 'package:eradealz/Screen/Privacy%20policy/privacy.dart';
import 'package:eradealz/Screen/Registration/registration.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:eradealz/Model/Dropmessage_Class.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';

class Contact extends StatefulWidget {
  const Contact({Key key}) : super(key: key);

  @override
  _ContactState createState() => _ContactState();
}

class _ContactState extends State<Contact> {
  String selectedValue;
  bool sending = false;

  final key = GlobalKey<FormState>();

  TextEditingController usernamecontroller = new TextEditingController();
  TextEditingController emailcontroller = new TextEditingController();
  TextEditingController phonecontroller = new TextEditingController();
  TextEditingController messagecontroller = new TextEditingController();

  void feedback(BuildContext context) async {
    var client = http.Client();

    String username = usernamecontroller.text;
    String email = emailcontroller.text;
    String phone = phonecontroller.text;
    String message = messagecontroller.text;

    var jsonresponse = await client.get(
        "https://eradealz.com/api/add_contact.php?" +
            "name=" +
            username +
            "&email=" +
            email +
            "&phone=" +
            phone +
            "&subject=" +
            selectedValue.toString() +
            "&message=" +
            message);

    if (jsonresponse.statusCode == 200) {
      // ignore: await_only_futures
      var response = await FeedbackApi.fromJson(jsonDecode(jsonresponse.body));

      print(jsonresponse.body);
      if (response.message == "Successfully added") {
        Fluttertoast.showToast(
            msg: "feedback added successfully !", textColor: Colors.white);

        setState(() {
          sending = false;
        });

        print("message send success");
      } else {
        print('message send failed');
      }
    } else {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          'Contact us',
          style: appBarStyle,
        ),
      ),
      body: Container(
        child: ListView(
          shrinkWrap: true,
          children: [
            SizedBox(height: size.height * 0.01),
            //Drop a message section
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
              child: Form(
                key: key,
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey,
                        offset: Offset(1, 1),
                        blurRadius: 1.0,
                        spreadRadius: 1.0,
                      ),
                    ],
                    borderRadius: BorderRadius.circular(15),
                    color: Colors.white,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      //Drop a message text
                      Container(
                        child: Text(
                          'Drop a message',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: eraMainTextColor,
                            fontSize: 20,
                          ),
                        ),
                      ),
                      SizedBox(height: size.height * 0.01),
                      //name
                      Container(
                        child: TextFormField(
                          controller: usernamecontroller,
                          textCapitalization: TextCapitalization.sentences,
                          validator: (value) {
                            if (value.isEmpty) {
                              return "please enter your name";
                            }
                            return null;
                          },
                          decoration: InputDecoration(labelText: "Name"),
                        ),
                      ),
                      //Email
                      Container(
                        child: TextFormField(
                          controller: emailcontroller,
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value.isEmpty) {
                              return "please enter your email";
                            } else if (!emailValidatorRegExp.hasMatch(value)) {
                              return "Please enter valid email";
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            labelText: "Email",
                            hintText: "",
                          ),
                        ),
                      ),
                      //mobile number
                      Container(
                        // margin: EdgeInsets.symmetric(horizontal: 15),
                        child: TextFormField(
                          controller: phonecontroller,
                          keyboardType: TextInputType.number,
                          maxLength: 10,
                          validator: (value) {
                            if (value.isEmpty) {
                              return "please enter your mobile number";
                            } else if (value.length != 10) {
                              return "Please enter valid mobile number";
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            labelText: "Mobile",
                            hintText: "",
                            prefixText: "+91 ",
                          ),
                        ),
                      ),

                      // Reason for Contact
                      Container(
                        child: DropdownButtonFormField(
                            validator: (value) {
                              if (value == null) {
                                return "please enter your reason";
                              }
                              return null;
                            },
                            hint: Text(
                              'Reason for contact',
                              style: TextStyle(),
                            ),
                            items: [
                              DropdownMenuItem(
                                  child: Text(" Question about my orders"),
                                  value: " Question about my orders"),
                              DropdownMenuItem(
                                  child: Text(" Returns / Exchange"),
                                  value: " Returns / Exchange"),
                              DropdownMenuItem(
                                  child: Text(" App error"),
                                  value: " App error"),
                              DropdownMenuItem(
                                  child: Text(" Others"), value: " Others"),
                            ],
                            value: selectedValue,
                            onChanged: (value) {
                              setState(() {
                                selectedValue = value;
                              });
                            }),
                      ),

                      //Message description
                      Container(
                        child: TextFormField(
                          controller: messagecontroller,
                          textCapitalization: TextCapitalization.sentences,
                          validator: (value) {
                            if (value.isEmpty) {
                              return "please enter your message";
                            }
                            return null;
                          },
                          decoration: InputDecoration(labelText: "Message"),
                        ),
                      ),

                      SizedBox(height: size.height * 0.04),

                      SizedBox(
                        height: size.height * 0.07,
                        width: size.width * 0.35,
                        child: ElevatedButton(
                          onPressed: () {
                            if (key.currentState.validate() &&
                                selectedValue != null) {
                              feedback(context);

                              setState(() {
                                sending = true;
                                usernamecontroller.clear();
                                emailcontroller.clear();
                                phonecontroller.clear();
                                selectedValue = null;
                                messagecontroller.clear();
                              });
                            }
                          },
                          child: Text(
                            sending == false ? "Send" : "Sending...",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                            onPrimary: Colors.white,
                            primary: eraPrimaryColor,
                            onSurface: Colors.grey,
                            elevation: 3,
                            shadowColor: Colors.grey,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            //Contact details section
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
              child: EraContact(),
            ),
            SizedBox(height: size.height * 0.02),
            //Contact details section
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    child: Text(
                      "Terms and Conditions",
                      style: TextStyle(
                        color: Colors.blue[300],
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                          context, CustomPageRoute(child: Privacy()));
                    },
                  ),
                ],
              ),
            ),
            SizedBox(height: size.height * 0.02),
          ],
        ),
      ),
    );
  }
}
