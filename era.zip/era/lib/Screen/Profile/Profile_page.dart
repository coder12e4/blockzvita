import 'package:eradealz/Screen/About/About_page.dart';
import 'package:eradealz/Screen/Delivery%20Address/View_address.dart';
import 'package:eradealz/Screen/Login/login.dart';
import 'package:eradealz/Screen/FAQ/FAQ_page.dart';
import 'package:eradealz/Screen/Order%20History/order_history.dart';
import 'package:eradealz/Widgets/connection_check.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:flutter/material.dart';
import '../Contact Us/Contact_page.dart';
import '../How It Works/Howitwork_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:connectivity/connectivity.dart'; //connectivity
class Profile extends StatefulWidget {

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  SharedPreferences prefs;

  String name, Email, Phone;
  bool _isInternetOn = true;

  void getdata() async {
    final prefs = await SharedPreferences.getInstance();
    String name1 = prefs.getString('username');
    String Email1 = prefs.getString('email');
    String Phone1 = prefs.getString('phone');

    setState(() {
      name = name1;
      Email = Email1;
      Phone = Phone1;
    });
  }

  logout() async {
    final SharedPreferences preference = await SharedPreferences.getInstance();
    preference.remove('userId');
    Navigator.pushReplacement(
        context, CustomPageRoute(child: LoginScreen()));
  }

  void checkConnection() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      setState(() {
        _isInternetOn = false;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    checkConnection(); //check internet is on or not
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: Container(
          child: Image.asset(
            "images/logo2.png",
            height: 48,
            width: 140,
          ),
        ),
        automaticallyImplyLeading: false,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        centerTitle: true,
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 10),
            child: IconButton(
              onPressed: () {
                showDialog(
                  builder: (ctxt) {
                    return AlertDialog(
                      shape: RoundedRectangleBorder(
                        side: BorderSide(color: Colors.white70, width: 1),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      title: Text(
                        "Logout",
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold),
                      ),
                      content: Text("Are you sure want to logout?"),
                      actions: [
                        Row(
                          children: [
                            SizedBox(height: size.height * 0.03),
                            SizedBox(width: size.width * 0.37),
                            IconButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                icon: Text(
                                  "No",
                                  style: TextStyle(
                                      color: Color(0xFFec1c24),
                                      fontWeight: FontWeight.bold),
                                )),
                            SizedBox(width: size.width * 0.07),
                            IconButton(
                              onPressed: () {
                                logout();
                              },
                              icon: Text(
                                "Yes",
                                style: TextStyle(
                                  color: Color(0xFFec1c24),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(height: size.height * 0.07),
                          ],
                        ),
                      ],
                    );
                  },
                  context: context,
                );
              },
              icon: Icon(
                Icons.logout_rounded,
                color: Colors.black,
              ),
            ),
          ),
        ],
      ),
      body: _isInternetOn ? ListView(
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                  top: 20,
                  left: 50,
                  right: 50,
                  bottom: 20,
                ),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Color(0xFFec1c24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white10,
                        offset: Offset(1, 1),
                        blurRadius: 1.0,
                        spreadRadius: 1.0,
                      ),
                    ],
                  ),
                  height: size.height * 0.2,
                  width: size.width,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      //name
                      Text(
                        name.toString(),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 24,
                        ),
                      ),
                      SizedBox(height: size.height * 0.01),
                      //email
                      Text(
                        Email.toString(),
                        style: TextStyle(
                          color: Colors.white70,
                        ),
                      ),
                      SizedBox(height: size.height * 0.01),
                      //mobile number
                      // Text(
                      //   Phone.toString(),
                      //   style: TextStyle(
                      //     color: Colors.grey,
                      //   ),
                      // ),
                    ],
                  ),
                ),
              ),


              //Order history and Delivery address
              Container(
                padding: EdgeInsets.symmetric(horizontal: 25),
                height: size.height * 0.1,
                width: size.width,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    OutlinedButton.icon(
                      icon: Icon(
                        Icons.history_outlined,
                        color: Colors.grey[850],
                      ),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                          color: Colors.grey[300],
                          width: 1,
                        ),
                      ),
                      label: Text(
                        "My Orders",
                        style: TextStyle(
                          color: Colors.grey[850],
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CustomPageRoute(
                                child: OrderHistory()));
                      },
                    ),
                    SizedBox(width: size.width * 0.01),


                    OutlinedButton.icon(
                      icon: Icon(
                        Icons.place_outlined,
                        color: Colors.grey[850],
                      ),
                      label: Text(
                        "Delivery Address",
                        style: TextStyle(
                          color: Colors.grey[850],
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(
                          color: Colors.grey[300],
                          width: 1,
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CustomPageRoute(
                                child: DeliveryAddress()));
                      },
                    ),
                  ],
                ),
              ),


              //Profile menu
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 25.0, vertical: 10.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    
                    //Contact us
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(
                          width: 1,
                          color: Colors.grey[300],
                        ),
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.grey[200],
                      ),
                      child: ListTile(
                        title: Text("Contact us"),
                        leading: Icon(
                          Icons.alternate_email_rounded,
                          color: Colors.black,
                        ),
                        trailing: Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 18,
                          color: Colors.black,
                        ),
                        onTap: () {
                          Navigator.push(
                              context,
                              CustomPageRoute(
                                  child: Contact()));
                        },
                      ),
                    ),

                    SizedBox(height: size.height * 0.03),

                    //about us
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(
                          width: 1,
                          color: Colors.grey[300],
                        ),
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.grey[200],
                      ),
                      child: ListTile(
                        title: Text("About us"),
                        leading: Icon(Icons.info_outlined, color: Colors.black),
                        trailing: Icon(Icons.arrow_forward_ios_rounded,
                            size: 18, color: Colors.black),
                        onTap: () {
                          Navigator.push(
                            context,
                            CustomPageRoute(
                              child: About(),
                            ),
                          );
                        },
                      ),
                    ),
                    SizedBox(height: size.height * 0.03),

                    
                    //How it works
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(
                          width: 1,
                          color: Colors.grey[300],
                        ),
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.grey[200],
                      ),
                      child: ListTile(
                        title: Text("How it works"),
                        leading: Icon(Icons.help_outline, color: Colors.black),
                        trailing: Icon(Icons.arrow_forward_ios_rounded,
                            size: 18, color: Colors.black),
                        onTap: () {
                          Navigator.push(
                            context,
                            CustomPageRoute(
                              child: work(),
                            ),
                          );
                        },
                      ),
                    ),
                    SizedBox(height: size.height * 0.03),
                    //faq
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        border: Border.all(
                          width: 1,
                          color: Colors.grey[300],
                        ),
                        borderRadius: BorderRadius.circular(30),
                        color: Colors.grey[200],
                      ),
                      child: ListTile(
                        title: Text("FAQ"),
                        leading: Icon(Icons.quiz_outlined, color: Colors.black),
                        trailing: Icon(Icons.arrow_forward_ios_rounded,
                            size: 18, color: Colors.black),
                        onTap: () {
                          Navigator.push(context,
                              CustomPageRoute(child: Faq()));
                        },
                      ),
                    ),
                    SizedBox(height: size.height * 0.03),
                  ],
                ),
              ),
            ],
          ),
        ],
      ) : ConnectionCheck(),
    );
  }
}
