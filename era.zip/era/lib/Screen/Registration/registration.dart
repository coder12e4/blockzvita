import 'dart:convert';
import 'package:eradealz/Model/SignUp_Class.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import '../Login/login.dart';
import 'package:http/http.dart' as http;
import 'package:eradealz/Screen//Forgot Password/Progress_dialog.dart';
import 'package:fluttertoast/fluttertoast.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key key}) : super(key: key);

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  ProgressDialog progressDialog;

  bool _showPassword = true;

  final key = GlobalKey<FormState>();

  TextEditingController usernamecontroller = new TextEditingController();
  TextEditingController emailcontroller = new TextEditingController();
  TextEditingController phonecontroller = new TextEditingController();
  TextEditingController addresscontroller = new TextEditingController();
  TextEditingController passwordcontroller = new TextEditingController();
  TextEditingController confpasswordcontroller = new TextEditingController();

  void SignUp(BuildContext context) async {
    progressDialog.show('Registering...');
    var client = http.Client();

    String username = usernamecontroller.text;
    String email = emailcontroller.text;
    String phone = phonecontroller.text;
    String address = addresscontroller.text;
    String password = passwordcontroller.text;
    String confpassword = confpasswordcontroller.text;

    var jsonresponse = await client.get(
      "https://eradealz.com/api/signup.php?" +
          "user_name=" +
          username +
          "&" +
          "phone=" +
          phone +
          "&" +
          "email=" +
          email +
          "&password=" +
          password +
          "&password_confirm=" +
          confpassword +
          "&address=" +
          address,
    );


      // ignore: await_only_futures
      var response = await SignupApi.fromJson(jsonDecode(jsonresponse.body));

      print(jsonresponse.body);

      progressDialog..hide(context);
      if (response.message == "Signup Success")
      {
        print("SignUp success");
        Fluttertoast.showToast(msg: "Registration successfully!");

        Navigator.push(context, CustomPageRoute(child: LoginScreen()));

      }
      else if(response.message=="Email Already exist..Use another Email.")
      {

        Fluttertoast.showToast(msg: "Email already exist use another email");

      }
      else if(response.message=="Phone Already exist..Use another Phone")
        {

          Fluttertoast.showToast(msg: "Phone number already exist use another phone number");
        }
      else
        {
        print('SignUp failed');

        Fluttertoast.showToast(msg: "Registration failed");
      }


  }

  @override
  Widget build(BuildContext context) {
    progressDialog = new ProgressDialog(context, ProgressDialogType.Normal);
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: Form(
        key: key,
        child: ListView(
          //mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: size.height * 0.03),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Image.asset(
                  "images/logo.png",
                  height: 80,
                  width: 160,
                ),
              ],
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Create Account",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.grey.shade600,
                  fontSize: 30,
                ),
                textAlign: TextAlign.left,
              ),
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 40),
              child: TextFormField(
                controller: usernamecontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "please enter your name";
                  } else {
                    return null;
                  }
                },
                decoration: InputDecoration(labelText: "Name"),
              ),
            ),
            SizedBox(height: size.height * 0.01),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 40),
              child: TextFormField(
                controller: emailcontroller,
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value.isEmpty) {
                    return "please enter your email";
                  } else if (!emailValidatorRegExp.hasMatch(value)) {
                    return "Please enter valid email";
                  }
                  return null;
                },
                decoration: InputDecoration(labelText: "Email"),
              ),
            ),
            SizedBox(height: size.height * 0.01),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 40),
              child: TextFormField(
                controller: phonecontroller,
                keyboardType: TextInputType.number,
                // maxLength: 10,
                validator: (value) {
                  if (value.isEmpty) {
                    return "please enter your mobile number";
                  } else if (value.length != 10) {
                    return "Please enter valid mobile number";
                  } else {}
                  return null;
                },
                decoration: InputDecoration(
                  labelText: "Mobile",
                  hintText: "",
                  prefixText: "+91 ",
                ),
              ),
            ),
            SizedBox(height: size.height * 0.01),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 40),
              child: TextFormField(
                controller: addresscontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "please enter your address";
                  }
                  return null;
                },
                decoration: InputDecoration(labelText: "address"),
              ),
            ),
            SizedBox(height: size.height * 0.01),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 40),
              child: TextFormField(
                controller: passwordcontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "please enter your password";
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: "Password",
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        _showPassword = !_showPassword;
                      });
                    },
                    icon: Icon(
                      _showPassword ? Icons.visibility_off : Icons.visibility,
                      color: Colors.grey,
                    ),
                  ),
                ),
                obscureText: _showPassword,
              ),
            ),
            SizedBox(height: size.height * 0.01),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 40),
              child: TextFormField(
                controller: confpasswordcontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "please confirm your password";
                  }
                  return null;
                },
                decoration: InputDecoration(labelText: "Retype Password"),
                obscureText: true,
              ),
            ),
            SizedBox(height: size.height * 0.06),
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 20.0, horizontal: 55),
              child: SizedBox(
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Color(0xFFec1c24),
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    padding: EdgeInsets.all(10),
                  ),
                  onPressed: () {
                    if (key.currentState.validate()) {
                      SignUp(context);
                    } else {
                      Fluttertoast.showToast(msg: "Registration failed");
                    }
                  },
                  child: Text(
                    "Sign Up",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Already have an account?",
                  style: TextStyle(
                    fontSize: 15,
                    color: Colors.grey.shade700,
                  ),
                ),
                SizedBox(width: size.width * 0.01),
                InkWell(
                  onTap: () => {
                    Navigator.push(context,
                        CustomPageRoute(child: LoginScreen()))
                  },
                  child: Text(
                    "Login",
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.grey.shade600,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: size.height * 0.07),
          ],
        ),
      ),
    );
  }
}
