import 'dart:convert';

import 'package:eradealz/Model/Usercheck_Class.dart';
import 'package:eradealz/Screen//Forgot Password/Progress_dialog.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

import '../OTP/otp_main.dart';

class MobileNumFetch extends StatefulWidget {
  //const MobileNumFetch({ Key? key }) : super(key: key);

  @override
  _MobileNumFetchState createState() => _MobileNumFetchState();
}

class _MobileNumFetchState extends State<MobileNumFetch> {
  ProgressDialog progressDialog;

  final key = GlobalKey<FormState>();
  final emailController = new TextEditingController();

  void checkEmail() async {
    progressDialog.show('Cheking...');
    var map = new Map<String, String>();
    map['id'] = emailController.text.trim();
    String email = emailController.text;

    var uri = await http
        .get("https://eradealz.com/api/user_check.php?" + "email=" + email);
    var response = await UsercheckApi.fromJson(jsonDecode(uri.body));
    print(uri.body);

    progressDialog..hide(context);
    if (response.message == "Success") {
      var user = jsonDecode(uri.body);
      print(user["id"]);
      print("verify email");

      Fluttertoast.showToast(msg: 'Verification Email Sent');
      Navigator.push(
          context,
          CustomPageRoute(
              child: Otp(
            uid: user['id'],
            emailId: emailController.text,
          )));
    } else {
      print("verify failed");

      Fluttertoast.showToast(msg: 'No user found');
    }
  }

  @override
  Widget build(BuildContext context) {
    progressDialog = new ProgressDialog(context, ProgressDialogType.Normal);
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: Form(
        key: key,
        child: ListView(
          //mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: size.height * 0.03),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Image.asset(
                  "images/logo.png",
                  height: 80,
                  width: 160,
                ),
              ],
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Forgot\nPassword",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade600,
                    fontSize: 36),
                textAlign: TextAlign.left,
              ),
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Enter the mail id below. We will send you recovery code.",
                // ignore: deprecated_member_use
                style: Theme.of(context).textTheme.subtitle1,
              ),
            ),
            SizedBox(height: size.height * 0.03),
            Padding(
              padding: const EdgeInsets.only(left: 30, right: 30, top: 40),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(3),
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.grey[100]),
                        height: MediaQuery.of(context).size.height * 0.1,
                        width: MediaQuery.of(context).size.width,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(width: size.width * 0.02),
                            Icon(
                              Icons.email,
                              color: Colors.black26,
                              size: 30,
                            ),
                            SizedBox(width: size.width * 0.05),
                            Container(
                              height: 30,
                              width: 220,
                              child: TextFormField(
                                controller: emailController,
                                showCursor: true,
                                validator: (value) {
                                  if (value.isEmpty) {
                                    return "pleace enter your email id";
                                  }
                                  return null;
                                },
                                keyboardType: TextInputType.emailAddress,
                                decoration: InputDecoration(
                                    hintText: "Email Id",
                                    hintStyle:
                                        TextStyle(color: Colors.black87)),
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
                decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.grey.shade100,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey.shade400,
                          blurRadius: 2,
                          spreadRadius: 1)
                    ]),
                height: MediaQuery.of(context).size.height * 0.15,
                width: MediaQuery.of(context).size.width,
              ),
            ),
            SizedBox(height: size.height * 0.05),
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 20.0, horizontal: 60),
              child: SizedBox(
                height: 50, //height of button
                //width of button
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Color(0xFFec1c24),
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    padding: EdgeInsets.all(10),
                  ),
                  onPressed: () {
                    if (key.currentState.validate()) {
                      if (emailController.text.toString().isEmpty) {
                        Fluttertoast.showToast(msg: 'Enter a valid email');
                      } else {
                        checkEmail();
                      }
                    }
                  },
                  child: Text(
                    "Verify email",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
