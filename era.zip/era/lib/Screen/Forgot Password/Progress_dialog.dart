import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

String _dialogMessage = "Loading...";
enum ProgressDialogType { Normal, Download }

ProgressDialogType _progressDialogType = ProgressDialogType.Normal;
double _progress = 0.0;

bool _isShowing = false;

class ProgressDialog {
  _MyDialog _dialog;

  BuildContext _buildContext, _context;

  ProgressDialog(
      BuildContext buildContext, ProgressDialogType progressDialogtype) {
    _buildContext = buildContext;

    _progressDialogType = progressDialogtype;
  }

  void setMessage(String mess) {
    _dialogMessage = mess;
  }

  /*void update({double progress, String message}) {
    debugPrint("ProgressDialog message changed: ");
    if (_progressDialogType == ProgressDialogType.Download) {
      debugPrint("Old Progress: $_progress, New Progress: $progress");
      _progress = progress;
    }
    debugPrint("Old message: $_dialogMessage, New Message: $message");
    _dialogMessage = message;
    _dialog.update();
  }*/

  bool isShowing() {
    return _isShowing;
  }

  void hide(BuildContext context) {
    if (_isShowing) {
      _isShowing = false;
      Navigator.of(context).pop();
    }
  }

  void show(String status) {
    if (!_isShowing) {
      _dialog = new _MyDialog(status);
      _isShowing = true;
      showDialog<dynamic>(
        context: _buildContext,
        barrierDismissible: false,
        builder: (BuildContext context) {
          _context = context;
          return Dialog(
              backgroundColor: Colors.white,
              insetAnimationCurve: Curves.easeInOut,
              insetAnimationDuration: Duration(milliseconds: 100),
              elevation: 10.0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10.0))),
              child: _dialog);
        },
      );
    }
  }
}
class _MyDialog extends StatefulWidget {
  var _dialog = new _MyDialogState();
  var status='';

  _MyDialog(this.status);

  update() {
    _dialog.changeState();
  }

  @override
  State<StatefulWidget> createState() {
    return _dialog;
  }
}

class _MyDialogState extends State<_MyDialog> {
  changeState() {
    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    _isShowing = false;
    debugPrint('ProgressDialog dismissed by back button');
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        height: 65.0,
        child: Row(children: <Widget>[
          const SizedBox(width: 20.0),
          SizedBox(
            child: CircularProgressIndicator(
              strokeWidth: 1,
            ),
            height: 23,
            width: 23,
          ),
          const SizedBox(width: 15.0),
          Expanded(
            child: _progressDialogType == ProgressDialogType.Normal
                ? Text(widget.status,
                textAlign: TextAlign.justify,
                style: TextStyle(
                    fontFamily: 'opensans',
                    color: Colors.black,
                    fontSize: 22.0,
                    fontWeight: FontWeight.w400))
                : Stack(
              children: <Widget>[
                Positioned(
                  child: Text(_dialogMessage,
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 22.0,
                          fontWeight: FontWeight.w700)),
                  top: 35.0,
                ),
                Positioned(
                  child: Text("$_progress/100",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 15.0,
                          fontWeight: FontWeight.w400)),
                  bottom: 15.0,
                  right: 15.0,
                ),
              ],
            ),
          )
        ],
        ),
    );
  }
}
