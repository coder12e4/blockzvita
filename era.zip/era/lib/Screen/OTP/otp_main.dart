import 'package:eradealz/Model/Usercheck_Class.dart';
import 'package:eradealz/Model/Userotp_Class.dart';
import 'package:eradealz/Screen/Reset%20Password/reset_password.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'otp_input.dart';
import 'package:eradealz/Screen//Forgot Password/Progress_dialog.dart';

class Otp extends StatefulWidget {
 final String emailId;
  final String uid;

  Otp({this.emailId,this.uid,});

  @override
  _OtpState createState() => _OtpState();
}

class _OtpState extends State<Otp> {

  bool viewVisible = false;

  resendCode() async{
    Fluttertoast.showToast(msg: 'Resending Code...');
    var map = new Map<String, String>();
    map['uid'] = widget.emailId;
    var uri = await http.get("https://eradealz.com/api/user_check.php?" + "email=" + widget.emailId);
    var response = await  UsercheckApi.fromJson(jsonDecode(uri.body));
    print(uri.body);
    if(response.message=="Success")
    {
      Fluttertoast.showToast(msg: 'Resend Code Success');
    }
  }


  ProgressDialog progressDialog;

  TextEditingController _pinEditingController = TextEditingController();

  static final TextStyle _textStyle = TextStyle(
      fontSize: 24,
      fontFamily: 'roboto',
      fontWeight: FontWeight.w400,
      color: Colors.black);

  static Color _solidColor = Colors.white54;
  static bool _solidEnable = true;
  static bool _obscureEnable = false;

  PinDecoration _pinDecoration = BoxLooseDecoration(
    radius: Radius.circular(16),
    textStyle: _textStyle,
    hintText: '----',
    solidColor: _solidEnable ? _solidColor : null,
    obscureStyle: ObscureStyle(
      isTextObscure: _obscureEnable,
      obscureText: '*',
    ),
  );



  void _onFormSubmitted() async {
    progressDialog.show('Verifying...');
    var map = new Map<String, String>();
    map['id'] = widget.uid;
    map['otp'] = _pinEditingController.text;
    String otpnum= _pinEditingController.text;


    var uri = await http.get("https://eradealz.com/api/otp_check.php?" + "otp=" + otpnum + "&" + "id=" + widget.uid);
    var response = await UserotpApi.fromJson(jsonDecode(uri.body));
    print(uri.body);

    progressDialog..hide(context);
    if(response.message=="OTP Verified"){

      var user = jsonDecode(uri.body);
      print(user['id']);

      Fluttertoast.showToast(msg: 'OTP Verification Success');
      Navigator.push(
          context,
          CustomPageRoute(
            child: ResetPassScreen(
              uid: user['id'],
            ),
          ));
    }
    else if(response.message=="OTP Mismathes..Check Your Mail")
    {
      Fluttertoast.showToast(msg: 'Error validating OTP, try again');
    }
    else
      {
      Fluttertoast.showToast(msg: 'Verification Failed');
    }

  }



  void dispose() {
    _pinEditingController.dispose();
    super.dispose();
  }




  @override
  Widget build(BuildContext context) {
    progressDialog = new ProgressDialog(context,ProgressDialogType.Normal);
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        body: ListView(children: [
      SizedBox(height: size.height * 0.03),
      Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Image.asset(
            "images/logo.png",
            height: 80,
            width: 160,
          ),
        ],
      ),
      SizedBox(height: size.height * 0.03),
      Container(
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.symmetric(horizontal: 40),
        child: Text("Enter 4\ndigit recovery code",
            style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade600)),
      ),
          SizedBox(height: size.height * 0.03),
      Container(
        alignment: Alignment.centerLeft,
        padding: EdgeInsets.symmetric(horizontal: 40),
        child: Text(
          "The Recovery code is sent to your registered mail id. Please enter the code:",
          // ignore: deprecated_member_use
          style: Theme.of(context).textTheme.caption,
        ),
      ),
          SizedBox(height: size.height * 0.05),
          Padding(
            padding: const EdgeInsets.only(right: 18),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                InkWell(
                  onTap:() {
                    resendCode();
                    setState(() {
                      viewVisible = true;
                    });

                  },
                  child: Text(
                    "Resend code?",
                    // ignore: deprecated_member_use
                    style: TextStyle(color: Colors.cyanAccent.shade700, fontSize: 17),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: size.height * 0.01),
      Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            height: 30,
          ),

          Padding(
            padding: EdgeInsets.only(left: 30, right: 30),
            child: PinInputTextField(
              pinLength: 4,
              decoration: _pinDecoration,
              controller: _pinEditingController,
              autoFocus: false,
              textInputAction: TextInputAction.done,
              onSubmit: (pin) {
                if (pin.length == 4) {
                  //_onFormSubmitted();
                }
                else {
                  Fluttertoast.showToast(msg: "Invalid OTP",textColor: Colors.white);
                }
              },
            ),
          ),


          SizedBox(height: size.height * 0.05),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "You will recevie your OTP in ",
                style: TextStyle(color: Colors.grey),
              ),
              TweenAnimationBuilder(
                  tween: Tween(begin: 30.0, end: 0),
                  duration: Duration(seconds: 30),
                  builder: (context, value, child) =>
                      Text("00:${value.toInt()}"))
            ],
          ),
        ],
      ),
      SizedBox(height: 10),
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 60),
        child: SizedBox(
          height: 50, //height of button
          //width of button
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              primary: Color(0xFFec1c24),
              elevation: 3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              padding: EdgeInsets.all(10),
            ),
            onPressed: () {
              if (_pinEditingController.text.length == 4) {
                _onFormSubmitted();
              }
              else
              {

                Fluttertoast.showToast(msg: "please enter the 4 digit otp code",textColor: Colors.white);
              }

            },
            child: Text(
              "Verify",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    ]));
  }
}
