import 'dart:convert';
import 'package:eradealz/Model/Viewcoupen_Class.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:eradealz/constant.dart';
import 'package:http/http.dart' as http;

class Coupens extends StatefulWidget {
  String oid, uname, offname, pname;

  Coupens({this.oid, this.uname, this.offname, this.pname});

  @override
  _CoupensState createState() => _CoupensState();
}

class _CoupensState extends State<Coupens> {
  Future<ViewcouponApi> viewcoupen() async {
    String url = "https://eradealz.com/api/coupon.php?" +
        "pur_id=" +
        widget.oid +
        "&username=" +
        widget.uname +
        "&offername=" +
        widget.offname +
        "&productname=" +
        widget.pname;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print("View coupen success");

      return ViewcouponApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    viewcoupen();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          'Coupens',
          style: appBarStyle,
        ),
      ),
      body: ListView(
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        children: [
          FutureBuilder(
              future: viewcoupen(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<Item> arr = snapshot.data.items;
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ListView.builder(
                        physics: BouncingScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: arr.length,
                        itemBuilder: (context, index) {
                          return Card(
                            color: Colors.white,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10, top: 10),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    arr[index].username,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(
                                    height: size.height * 0.01,
                                  ),
                                  Text("RAFFLE NUMBER :"),
                                  Text(
                                    arr[index].raffleId,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: eraPrimaryColor,
                                    ),
                                  ),
                                  SizedBox(
                                    height: size.height * 0.07,
                                  ),
                                  Text(
                                      "CAMPAIGN NAME : " + arr[index].campaign),
                                  SizedBox(
                                    height: size.height * 0.01,
                                  ),
                                  Text("PRODUCT NAME : " +
                                      arr[index].productname),
                                  SizedBox(
                                    height: size.height * 0.04,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 10),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Container(
                                          height: size.height * 0.04,
                                          child: Center(
                                            child: Text(
                                              "  " + arr[index].raffleId + "  ",
                                              style: TextStyle(
                                                  color: Colors.white),
                                            ),
                                          ),
                                          decoration: BoxDecoration(
                                              color: eraPrimaryColor,
                                              borderRadius:
                                                  BorderRadius.circular(5)),
                                        )
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    height: size.height * 0.02,
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                  );
                } else {
                  return Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.37,
                      ),
                      Center(child: Loading()),
                    ],
                  );
                }
              })
        ],
      ),
    );
  }
}
