import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:eradealz/Model/OrderHistory_Class.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'ViewCoupen.dart';

class OrderHistory extends StatefulWidget {
  @override
  _OrderHistoryState createState() => _OrderHistoryState();
}

class _OrderHistoryState extends State<OrderHistory> {
  Future<OrderHistoryApi> FetchOrderHistory() async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');

    String url = "https://eradealz.com/api/order_history.php?" + "id=" + userid;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print("Order history success");

      return OrderHistoryApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    FetchOrderHistory();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          'Order History',
          style: appBarStyle,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),
        child: ListView(
          shrinkWrap: true,
          physics: BouncingScrollPhysics(),
          children: [
            FutureBuilder(
                future: FetchOrderHistory(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    List<Item> arr = snapshot.data.items;
                    return ListView.builder(
                        physics: BouncingScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: arr.length,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.white,
                              ),
                              padding: EdgeInsets.all(10.0),
                              child: Column(
                                children: [
                                  //First row
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "ORDER ID : " + arr[index].purId,
                                            style: TextStyle(
                                              fontSize: 13,
                                              color: Colors.grey.shade800,
                                            ),
                                          ),
                                          SizedBox(height: size.height * 0.008),
                                          Text(
                                            arr[index].productName.toString(),
                                            style: TextStyle(
                                              fontSize: 10,
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: [
                                          Text(
                                            "Delivered",
                                            style: TextStyle(
                                              fontSize: 14,
                                              color: Colors.green,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  Divider(),
                                  Container(
                                    margin: EdgeInsets.symmetric(vertical: 3),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          arr[index].quantity,
                                          style: TextStyle(),
                                        ),
                                        Text(
                                          arr[index].amount,
                                          style: TextStyle(),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Divider(),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Orderd On",
                                        style: TextStyle(),
                                      ),
                                      Text("Order Date"),
                                    ],
                                  ),

                                  SizedBox(
                                    height: size.height * 0.03,
                                  ),

                                  //track order View coupon row
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Material(
                                        color: Colors.transparent,
                                        child: InkWell(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          splashColor: Colors.grey[50],
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                CustomPageRoute(
                                                    child:
                                                        Coupens(
                                                          oid: arr[index].purId,
                                                          pname: arr[index]
                                                              .productName,
                                                          uname: arr[index]
                                                              .username,
                                                          offname: arr[index]
                                                              .campaign,
                                                        )));
                                          },
                                          child: Container(
                                            height: size.height * 0.06,
                                            width: size.width * 0.38,
                                            padding: EdgeInsets.all(5),
                                            decoration: BoxDecoration(
                                              // color: Colors.blue,
                                              border: Border.all(
                                                  color: Colors.teal.shade200,
                                                  width: 2),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: Center(
                                              child: Text(
                                                "View Coupons",
                                                style: TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.teal.shade300,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: size.width * 0.05,
                                      ),
                                      Material(
                                        color: Colors.transparent,
                                        child: InkWell(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          splashColor: Colors.grey[50],
                                          onTap: () {},
                                          child: Container(
                                            height: size.height * 0.06,
                                            width: size.width * 0.38,
                                            padding: EdgeInsets.all(5),
                                            decoration: BoxDecoration(
                                              // color: Colors.blue,
                                              border: Border.all(
                                                  color: Colors.teal.shade200,
                                                  width: 2),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: Center(
                                              child: Text(
                                                "Track Order",
                                                style: TextStyle(
                                                    fontSize: 13,
                                                    color: Colors.teal.shade300,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  SizedBox(
                                    height: size.height * 0.02,
                                  ),
                                ],
                              ),
                            ),
                          );
                        });
                  } else {
                    return Column(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.35,
                        ),
                        Center(child: Loading()),
                      ],
                    );
                  }
                })
          ],
        ),
      ),
    );
  }
}
