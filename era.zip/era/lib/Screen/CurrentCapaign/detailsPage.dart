import 'dart:convert';
import 'package:eradealz/Model/Campaign_dtls_Clas.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';

class Campdetails extends StatefulWidget {
  String cat_Id;

  Campdetails({this.cat_Id});

  @override
  _CampdetailsState createState() => _CampdetailsState();
}

class _CampdetailsState extends State<Campdetails> {
  Future<CampaigndetailsApi> getdata() async {
    String url = "https://eradealz.com/api/campaign_details.php?" + "cat_id=" + widget.cat_Id;

    var responce = await http.get(url);

    if (responce.statusCode == 200)
    {
      print("camp dtls success");

      return CampaigndetailsApi.fromJson(jsonDecode(responce.body));
    }
    else
      {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
          automaticallyImplyLeading: true,
          iconTheme: IconThemeData(color: Colors.black),
          title: Container(
            child: Image.asset(
              "images/logo2.png",
              height: 48,
              width: 140,
            ),
          ),
          backgroundColor: Colors.white,
          centerTitle: true,
          actions: <Widget>[]),
      body: ListView(
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        children: [
          SizedBox(height: size.height * 0.02),
          FutureBuilder(
              future: getdata(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<Item> arr = snapshot.data.items;

                  return ListView.builder(
                      physics: BouncingScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: arr.length,
                      itemBuilder: (context, index) {
                        return ListView(
                          shrinkWrap: true,
                          physics: BouncingScrollPhysics(),
                          children: [
                            //image

                            Container(
                              height: size.height * 0.34,
                              width: size.width * 0.9999,
                              child: CachedNetworkImage(
                                imageUrl: arr[index].offerPhoto.toString(),
                                fit: BoxFit.fill,
                                placeholder: (context, url) => Shimmer.fromColors(
                                  baseColor: Colors.grey.shade200,
                                  highlightColor: Colors.grey.shade50,
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(1),
                                      child: Container(
                                        height: size.height * 0.34,
                                        width: size.width * 0.9999,
                                        color: Colors.grey.shade100,
                                      )),
                                ),
                                errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                              ),
                            ),


                            SizedBox(height: size.height * 0.03),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 10, right: 10),
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(25),
                                  color: Colors.grey.shade200,
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    SizedBox(height: size.height * 0.03),
                                    //image
                                    Text(
                                      arr[index].name,
                                      style: TextStyle(
                                          fontSize: 23,
                                          color: Colors.grey.shade600),
                                    ),
                                    SizedBox(height: size.height * 0.03),
                                    Text(
                                      "Descriptions:",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20,
                                          color: Colors.black),
                                    ),
                                    SizedBox(height: size.height * 0.03),
                                    Text(
                                      "Read:",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.grey.shade700),
                                    ),
                                    Text(
                                      arr[index].description,
                                      style: TextStyle(
                                          fontSize: 17,
                                          color: Colors.grey.shade600),
                                      textAlign: TextAlign.center
                                    ),
                                    SizedBox(height: size.height * 0.03),
                                    Text(
                                      "Start Date:",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.grey.shade700),
                                    ),
                                    Text(
                                      arr[index].fromDate.toString(),
                                      style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.red,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(height: size.height * 0.03),
                                    Text(
                                      "End Date:",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.grey.shade700),
                                    ),
                                    Text(
                                      arr[index].toDate.toString(),
                                      style: TextStyle(
                                          fontSize: 15,
                                          color: Colors.red,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(height: size.height * 0.03),
                                    Text(
                                      "Draw Date:",
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                          color: Colors.grey.shade700),
                                    ),
                                    Text(
                                      arr[index].day,
                                      style: TextStyle(
                                          fontSize: 17,
                                          color: Colors.grey.shade600),
                                    ),
                                    SizedBox(height: size.height * 0.03),
                                    Text(
                                      "AVAILABLE",
                                      style: TextStyle(
                                          fontSize: 17,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(height: size.height * 0.02),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: size.height * 0.1),
                            // Column(
                            //   children: [
                            //     Row(
                            //       children: [
                            //         SizedBox(width: size.width * 0.04),
                            //         Text(
                            //           "How it works",
                            //           style: TextStyle(
                            //               fontWeight: FontWeight.bold,
                            //               color: Colors.grey.shade700,
                            //               fontSize: 20),
                            //         )
                            //       ],
                            //     ),
                            //     SizedBox(height: size.height * 0.02),
                            //     Row(
                            //       children: [
                            //         SizedBox(width: size.width * 0.04),
                            //         Text(
                            //           "lorem lorem",
                            //           style: TextStyle(
                            //               color: Colors.grey.shade700,
                            //               fontSize: 15),
                            //         )
                            //       ],
                            //     ),
                            //     SizedBox(height: size.height * 0.03),
                            //     Row(
                            //       children: [
                            //         SizedBox(width: size.width * 0.04),
                            //         Text(
                            //           "How the winner Is Picked",
                            //           style: TextStyle(
                            //               fontWeight: FontWeight.bold,
                            //               color: Colors.grey.shade700,
                            //               fontSize: 20),
                            //         )
                            //       ],
                            //     ),
                            //     SizedBox(height: size.height * 0.02),
                            //     Row(
                            //       children: [
                            //         SizedBox(width: size.width * 0.04),
                            //         Text(
                            //           "lorem",
                            //           style: TextStyle(
                            //               color: Colors.grey.shade700,
                            //               fontSize: 15),
                            //         )
                            //       ],
                            //     ),
                            //   ],
                            // ),
                          ],
                        );
                      });
                } else {
                  return Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      Center(child: Loading()),
                    ],
                  );
                }
              }),
        ],
      ),
    );
  }
}
