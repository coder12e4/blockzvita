import 'dart:convert';
import 'package:eradealz/Components/bottomNav.dart';
import 'package:eradealz/Model/Campaign_Class.dart';
import 'package:eradealz/Screen/CurrentCapaign/detailsPage.dart';
import 'package:eradealz/Widgets/connection_check.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';

import 'package:connectivity/connectivity.dart'; //connectivity


class campaigns extends StatefulWidget {
  String backicon;

  campaigns({this.backicon});

  @override
  _campaignsState createState() => _campaignsState();
}

var refreshKey=GlobalKey<RefreshIndicatorState>();

class _campaignsState extends State<campaigns> {

  bool _isInternetOn = true;

  Future<CampaignApi> getdata() async {
    String url = "https://eradealz.com/api/campaign.php";

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Camp Success");

      return CampaignApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  void checkConnection() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      setState(() {
        _isInternetOn = false;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    checkConnection(); //check internet is on or not
  }

  

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        leading: widget.backicon == "true"
            ? IconButton(
                onPressed: () {
                  Navigator.pop(context,
                      MaterialPageRoute(builder: (context) => BottomNav()));
                },
                icon: Icon(
                  Icons.arrow_back,
                  color: Colors.black,
                ),
              )
            : null,
        iconTheme: IconThemeData(color: Colors.black),
        title: Container(
          child: Image.asset(
            "images/logo2.png",
            height: 48,
            width: 140,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      body: _isInternetOn ? RefreshIndicator(
        key: refreshKey,
        onRefresh: refreshList,
        child: ListView(
          physics: ScrollPhysics(),
          shrinkWrap: true,
          children: [
            SizedBox(height: size.height * 0.03),
            Row(
              children: [
                SizedBox(width: size.width * 0.05),
                Image.asset(
                  "images/icon2.png",
                  height: 50,
                  width: 50,
                ),
                SizedBox(width: size.width * 0.06),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Current Campaigns",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFec1c24),
                          fontSize: 20),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "Select a giveaway to learn more",
                      style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
                    ),
                  ],
                ),
              ],
            ),
            FutureBuilder(
              future: getdata(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<Item> arr = snapshot.data.items;
                  return ListView.builder(
                      physics: ScrollPhysics(),
                      itemCount: arr.length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              CustomPageRoute(
                                child:  Campdetails(
                                  cat_Id: arr[index].id,
                                ),
                              ),
                            );
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                            child: Container(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(3),
                                    child: Container(
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          color: Colors.white),
                                      height: 110,
                                      width: MediaQuery.of(context).size.width,
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          SizedBox(width: size.width * 0.03),
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(1),
                                            child: Container(
                                              height: size.height * 0.13,
                                              width: size.width * 0.37,
                                              child: CachedNetworkImage(
                                                imageUrl: arr[index].offerPhoto.toString(),
                                                fit: BoxFit.fill,
                                                placeholder: (context, url) => Shimmer.fromColors(
                                                  baseColor: Colors.grey.shade200,
                                                  highlightColor: Colors.grey.shade50,
                                                  child: ClipRRect(
                                                      borderRadius: BorderRadius.circular(1),
                                                      child: Container(
                                                        height: size.height * 0.13,
                                                        width: size.width * 0.37,
                                                        color: Colors.grey.shade100,
                                                      )),
                                                ),
                                                errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                                              ),
                                            ),
                                          ),
                                          SizedBox(width: size.width * 0.17),
                                          Text(
                                            arr[index].name,
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              decoration: BoxDecoration(
                                  shape: BoxShape.rectangle,
                                  borderRadius: BorderRadius.circular(4),
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.white,
                                        blurRadius: 1,
                                        spreadRadius: 1)
                                  ]),
                              height: 120,
                            ),
                          ),
                        );
                      });
                } else {
                  return Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      Center(
                        child: Loading(),
                      ),
                    ],
                  );
                }
              },
            ),
          ],
        ),
      ) : ConnectionCheck(),
    );
  }
  Future<void> refreshList() async{
    refreshKey.currentState.show(atTop: false);
    await Future.delayed(Duration(seconds: 2));
    setState(() {
      getdata();
    });
    return null;
  }
}
