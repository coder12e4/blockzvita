import 'dart:convert';
import 'package:eradealz/Components/bottomNav.dart';
import 'package:eradealz/Model/Login_Class.dart';
import 'package:eradealz/Screen/Registration/registration.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import '../Forgot Password/Forgotpass.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:eradealz/Screen//Forgot Password/Progress_dialog.dart';
import 'package:fluttertoast/fluttertoast.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  ProgressDialog progressDialog;
  bool _showPassword = true;

  TextEditingController emailcontroller = new TextEditingController();
  TextEditingController passwordcontroller = new TextEditingController();

  final key = GlobalKey<FormState>();

  void login(BuildContext context) async {
    progressDialog.show('Loading...');
    // ignore: unused_local_variable
    final formstate = key.currentState;

    var client = http.Client();

    String email = emailcontroller.text;
    String password = passwordcontroller.text;

    var jsonresponse = await client.post(
      "https://eradealz.com/api/login.php?" +
          "email" +
          "=" +
          email +
          "&" +
          "password" +
          "=" +
          password,
    );

    if (jsonresponse.statusCode == 200) {
      var response = await LoginApi.fromJson(jsonDecode(jsonresponse.body));

      progressDialog..hide(context);
      if (response.message == "Login Success") {
        print('login success');

        List<Item> user = response.items;
        String username = user[0].name;
        String email = user[0].email;
        String phone = user[0].phone;
        String userId = user[0].id;
        String rflcode = user[0].referal;

        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('email', email);
        prefs.setString('phone', phone);
        prefs.setString('userId', userId);
        prefs.setString('rflcode', rflcode);

        Fluttertoast.showToast(msg: "Login successfully!");
        Navigator.pushReplacement(context, CustomPageRoute(child: BottomNav()));
      }
      // else if(response.message=="Invalid User name Or Password")
      // {
      //
      //   Fluttertoast.showToast(msg: "Invalid User name Or Password");
      //
      // }
      else {
        print('login failed');

        // ignore: deprecated_member_use
        Fluttertoast.showToast(msg: "Login failed");
      }
    } else {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    progressDialog = new ProgressDialog(context, ProgressDialogType.Normal);
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: Form(
        key: key,
        child: ListView(
          children: <Widget>[
            SizedBox(height: size.height * 0.03),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Image.asset(
                  "images/logo.png",
                  height: 80,
                  width: 160,
                ),
              ],
            ),
            SizedBox(height: size.height * 0.03),

            //Username or email
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Login",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  color: Colors.grey.shade700,
                ),
                textAlign: TextAlign.left,
              ),
            ),
            SizedBox(height: size.height * 0.05),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 40),
              child: TextFormField(
                controller: emailcontroller,
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value.isEmpty) {
                    return "please enter your email id";
                  } else if (!emailValidatorRegExp.hasMatch(value)) {
                    return "Please enter valid email";
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: "Email",
                ),
              ),
            ),
            SizedBox(height: size.height * 0.03),

            //Passsword
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(horizontal: 40),
              child: TextFormField(
                controller: passwordcontroller,
                validator: (value) {
                  if (value.isEmpty) {
                    return "please enter your password";
                  }
                  return null;
                },
                obscureText: _showPassword,
                decoration: InputDecoration(
                  labelText: "Password",
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        _showPassword = !_showPassword;
                      });
                    },
                    icon: Icon(
                      _showPassword ? Icons.visibility_off : Icons.visibility,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: size.height * 0.01),
            //forgot password
            Container(
              alignment: Alignment.centerRight,
              margin: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
              child: GestureDetector(
                onTap: () => {
                  // Navigator.push(context, MaterialPageRoute(builder: (context) => MobileNumFetch()));
                },
                child: InkWell(
                  onTap: () => {
                    Navigator.push(
                      context,
                      CustomPageRoute(child: MobileNumFetch()),
                    ),
                  },
                  child: Text(
                    "Forgot password?",
                    style: TextStyle(
                      decoration: TextDecoration.underline,
                      fontSize: 15,
                      color: eraMainTextColor,
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: size.height * 0.01),
            //login button
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 20.0, horizontal: 45),
              child: SizedBox(
                height: 50,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Color(0xFFec1c24),
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    padding: EdgeInsets.all(10),
                  ),
                  onPressed: () {
                    if (key.currentState.validate()) {
                      login(context);
                    } else {
                      Fluttertoast.showToast(msg: "Login failed");
                    }
                  },
                  child: Text(
                    "Login",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
            Container(
              alignment: Alignment.center,
              margin: EdgeInsets.symmetric(
                horizontal: 40,
                vertical: 5.0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Don't Have an Account?",
                    style: TextStyle(
                      fontSize: 15,
                      color: eraMainTextColor,
                    ),
                  ),
                  SizedBox(width: size.width * 0.01),
                  InkWell(
                    onTap: () {
                      Navigator.push(
                          context, CustomPageRoute(child: RegisterScreen()));
                    },
                    child: Text(
                      "Sign up",
                      style: TextStyle(
                        fontSize: 15,
                        color: eraMainTextColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
