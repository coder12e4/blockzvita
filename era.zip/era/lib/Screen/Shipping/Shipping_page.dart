import 'dart:convert';
import 'package:eradealz/Model/OrderInfo_Class.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_html/flutter_html.dart';

class Shipp extends StatefulWidget {
  const Shipp({Key key}) : super(key: key);

  @override
  _ShippState createState() => _ShippState();
}

class _ShippState extends State<Shipp> {
  Future<OrderinfoApi> getdata() async {
    String url = "https://eradealz.com/api/order_info.php";

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Success");

      return OrderinfoApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          'Order Information',
          style: appBarStyle,
        ),
      ),
      body: ListView(
        shrinkWrap: true,
        children: [
          SizedBox(height: size.height * 0.03),
          FutureBuilder(
              future: getdata(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<Item> arr = snapshot.data.items;
                  return ListView.builder(
                      physics: BouncingScrollPhysics(),
                      itemCount: arr.length,
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(left: 15, right: 15),
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Html(
                                  data: arr[index].orderinfo,
                                ),
                                SizedBox(height: size.height * 0.01),
                              ],
                            ),
                          ),
                        );
                      });
                } else {
                  return Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      Center(child: Loading()),
                    ],
                  );
                }
              }),
        ],
      ),
    );
  }
}
