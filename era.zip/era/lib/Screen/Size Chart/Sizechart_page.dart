import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';

class Sizechart extends StatefulWidget {
  const Sizechart({Key key}) : super(key: key);

  @override
  _SizechartState createState() => _SizechartState();
}

class _SizechartState extends State<Sizechart> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
          automaticallyImplyLeading: true,
          iconTheme: IconThemeData(color: Colors.black),
          backgroundColor: Colors.white,
          title: Text(
            'Size Chart',
            style: appBarStyle,
          )),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: ListView(
          children: [
            SizedBox(height: size.height * 0.03),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'T-Shirt Size Chart',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                      fontSize: 17,
                    ),
                  ),
                  SizedBox(height: size.height * 0.02),
                  Text('Size Measurements:'),
                ],
              ),
            ),
            SizedBox(height: size.height * 0.04),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  //table
                  Container(
                    child: DataTable(
                      columns: [
                        DataColumn(
                            label: Text('Size',
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold))),
                        DataColumn(
                            label: Text('Length',
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold))),
                        DataColumn(
                            label: Text('Width',
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.bold))),
                      ],
                      rows: [
                        DataRow(cells: [
                          DataCell(Text('S')),
                          DataCell(Text('28')),
                          DataCell(Text('18')),
                        ]),
                        DataRow(cells: [
                          DataCell(Text('M')),
                          DataCell(Text('29')),
                          DataCell(Text('20')),
                        ]),
                        DataRow(cells: [
                          DataCell(Text('L')),
                          DataCell(Text('30')),
                          DataCell(Text('22')),
                        ]),
                        DataRow(cells: [
                          DataCell(Text('LX')),
                          DataCell(Text('31')),
                          DataCell(Text('24')),
                        ]),
                        DataRow(cells: [
                          DataCell(Text('2LX')),
                          DataCell(Text('32')),
                          DataCell(Text('26')),
                        ]),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: size.height * 0.04),
            Text('Don\'t Worry, We Offer Exchanges.'),
            SizedBox(height: size.height * 0.01),
            Row(
              children: [
                Text('More info can be found in '),
                Text(
                  'Returns & Exchanges',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.black54,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
