import 'dart:async';

import 'package:eradealz/Components/bottomNav.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:flutter/material.dart';
import '../Login/login.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Splash extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  String finalUserId;

  Future getValidationData() async {
    final SharedPreferences preference = await SharedPreferences.getInstance();
    var obtainedUseId = preference.getString('userId');
    setState(() {
      finalUserId = obtainedUseId;
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getValidationData().whenComplete(() async {
      Timer(
        Duration(seconds: 5),
        () => Navigator.pushReplacement(
          context,
          CustomPageRoute(
            child: finalUserId == null ? LoginScreen() : BottomNav(),
          ),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    // Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Center(
        child: Image.asset(
          "images/logo.png",
          height: 150,
          width: 150,
        ),
      ),
    );
  }
}
