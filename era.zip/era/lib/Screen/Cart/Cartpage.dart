import 'dart:convert';
import 'dart:ui';
import 'package:eradealz/Components/bottomNav.dart';
import 'package:eradealz/Model/Cartdlt_Class.dart';
import 'package:eradealz/Model/Cartview_Class.dart';
import 'package:eradealz/Model/Totalprice_Class.dart';
import 'package:eradealz/Model/Updatecartqty_Class.dart';
import 'package:eradealz/Screen/Payment/payment.dart';
import 'package:eradealz/Widgets/connection_check.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';

import 'package:connectivity/connectivity.dart'; //connectivity

class Cart_Page extends StatefulWidget {
  @override
  _Cart_PageState createState() => _Cart_PageState();
}

var refreshKey = GlobalKey<RefreshIndicatorState>();

class _Cart_PageState extends State<Cart_Page> {
  String cartid;
  int val = 1;
  bool _isInternetOn = true;

  Future<UpdatecartqtyApi> updateqty(String cartid) async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');

    String url = "https://eradealz.com/api/update_quantity.php?" +
        "id=" +
        userid +
        "&cart_id=" +
        cartid +
        "&value=" +
        val.toString();

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print("Quantity Updated");

      return UpdatecartqtyApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  //check connection if internet on or not
  void checkConnection() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      setState(() {
        _isInternetOn = false;
      });
    }
  }

  //cart view
  Future<CartviewApi> Cartview() async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');

    String url = "https://eradealz.com/api/cart_view.php?" + "id=" + userid;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print(responce.body);
      print("Cart view success");
      return CartviewApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  //total
  Future<TotalpriceApi> Total() async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');
    String url = "https://eradealz.com/api/cart_total.php?" + "id=" + userid;
    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Total price success");


      return TotalpriceApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  //cart delete
  Future<CartdeleteApi> cartdlt(String cartid) async {
    String url =
        "https://eradealz.com/api/delete_cart.php?" + "cart_id=" + cartid;

    var uri = await http.get(url);

    if (uri.statusCode == 200) {
      var responce = CartdeleteApi.fromJson(jsonDecode(uri.body));
      if (responce.message == "Cart Deleted.") {
        print("Cart delete success");
        return responce;
      }
    } else {
      print("No Connection");
    }
  }

  _getin() async {
    setState(() {
      val++;
    });
  }

  _getdec() async {
    if (val > 1) {
      setState(() {
        val--;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Cartview();
    Total();
    checkConnection();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Colors.grey[100],
      //Appbar
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.black),
        automaticallyImplyLeading: true,
        backgroundColor: Colors.white,
        title: Text('My cart', style: appBarStyle),
      ),
      //body
      body: _isInternetOn
          ? RefreshIndicator(
              key: refreshKey,
              onRefresh: refreshList,
              child: ListView(
                physics: BouncingScrollPhysics(),
                shrinkWrap: true,
                children: [
                  FutureBuilder(
                      future: Cartview(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          List<Item> arr = [];
                          arr.clear();
                          arr = snapshot.data.items;
                          return arr.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      SizedBox(
                                        height:
                                            MediaQuery.of(context).size.height /
                                                3,
                                      ),
                                      Text(
                                        'Your cart is empty!',
                                        style: TextStyle(
                                          fontSize: 18,
                                          color: eraMainTextColor,
                                        ),
                                      ),
                                      SizedBox(height: size.height * 0.01),
                                      Text(
                                        'Add items to it now.',
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: eraTextColor,
                                        ),
                                      ),
                                      SizedBox(height: size.height * 0.01),
                                      ElevatedButton(
                                        onPressed: () {
                                          Navigator.push(
                                              context,
                                              CustomPageRoute(
                                                  child: BottomNav()));
                                        },
                                        child: Text("Shop now"),
                                        style: ElevatedButton.styleFrom(
                                          primary: eraPrimaryColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : ListView.builder(
                                  physics: BouncingScrollPhysics(),
                                  shrinkWrap: true,
                                  itemCount: arr.length,
                                  itemBuilder: (context, index) {
                                    cartid = arr[index].cartId.toString();
                                    return Padding(
                                      padding: const EdgeInsets.all(5.0),
                                      child: Card(
                                        child: Container(
                                          child: Column(
                                            children: [
                                              SizedBox(
                                                height: size.height * 0.02,
                                              ),
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceAround,
                                                children: [
                                                  //image column
                                                  ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            1),
                                                    child: Container(
                                                      height: size.height * 0.1,
                                                      width: size.width * 0.2,
                                                      child: CachedNetworkImage(
                                                        imageUrl: arr[index]
                                                            .photo
                                                            .toString(),
                                                        fit: BoxFit.fill,
                                                        placeholder: (context,
                                                                url) =>
                                                            Shimmer.fromColors(
                                                          baseColor: Colors
                                                              .grey.shade200,
                                                          highlightColor: Colors
                                                              .grey.shade50,
                                                          child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        1),
                                                            child: Container(
                                                              height:
                                                                  size.height *
                                                                      0.1,
                                                              width:
                                                                  size.width *
                                                                      0.2,
                                                              color: Colors.grey
                                                                  .shade100,
                                                            ),
                                                          ),
                                                        ),
                                                        errorWidget: (context,
                                                                url, error) =>
                                                            Image.asset(
                                                          "images/ina.jpg",
                                                          fit: BoxFit.fill,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  //details col
                                                  Container(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          arr[index]
                                                              .productName,
                                                          style: TextStyle(
                                                              fontSize: 17),
                                                        ),
                                                        Text(
                                                          "\$ " +
                                                              arr[index].price,
                                                          style: TextStyle(
                                                              color: Colors
                                                                  .lightBlueAccent),
                                                        ),
                                                        Text(
                                                          "Color: " +
                                                              arr[index].color,
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.black,
                                                              fontSize: 13),
                                                        ),
                                                        Text(
                                                          "Size: " +
                                                              arr[index].size,
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.black,
                                                              fontSize: 13),
                                                        ),
                                                        SizedBox(
                                                            height:
                                                                size.height *
                                                                    0.01),
                                                      ],
                                                    ),
                                                  ),
                                                  //quantity column
                                                  Container(
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        InkWell(
                                                          child: Container(
                                                            height:
                                                                size.height *
                                                                    0.04,
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          6),
                                                              color: Colors.grey
                                                                  .shade100,
                                                            ),
                                                            child: Row(
                                                              children: [
                                                                SizedBox(
                                                                  width:
                                                                      size.width *
                                                                          0.01,
                                                                ),
                                                                Text(
                                                                  "Qty",
                                                                  style:
                                                                      TextStyle(
                                                                    fontSize:
                                                                        13,
                                                                    color: Colors
                                                                        .black38,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width:
                                                                      size.width *
                                                                          0.01,
                                                                ),
                                                                Text(
                                                                  arr[index]
                                                                      .quantity,
                                                                  style:
                                                                      TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    fontSize:
                                                                        11,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                    width: size
                                                                            .width *
                                                                        0.01),
                                                                Icon(
                                                                  Icons
                                                                      .keyboard_arrow_down_outlined,
                                                                  size: 13,
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          onTap: () async {
                                                            await showModalBottomSheet(
                                                              shape:
                                                                  RoundedRectangleBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .vertical(
                                                                  top: Radius
                                                                      .circular(
                                                                          10),
                                                                ),
                                                              ),
                                                              clipBehavior: Clip
                                                                  .antiAliasWithSaveLayer,
                                                              context: context,
                                                              builder:
                                                                  (BuildContext
                                                                      bc) {
                                                                return StatefulBuilder(builder:
                                                                    (BuildContext
                                                                            context,
                                                                        StateSetter
                                                                            setState) {
                                                                  return Container(
                                                                    padding:
                                                                        EdgeInsets
                                                                            .symmetric(
                                                                      horizontal:
                                                                          25,
                                                                      vertical:
                                                                          20,
                                                                    ),
                                                                    height: size
                                                                            .height *
                                                                        0.33,
                                                                    child:
                                                                        new Column(
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .spaceBetween,
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      children: <
                                                                          Widget>[
                                                                        //select quantity heading text
                                                                        Container(
                                                                          child:
                                                                              Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.center,
                                                                            children: [
                                                                              Text(
                                                                                "Select Quantity",
                                                                                style: TextStyle(
                                                                                  fontSize: 17,
                                                                                  fontWeight: FontWeight.bold,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        //quantity actions
                                                                        Container(
                                                                          child:
                                                                              Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.start,
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.center,
                                                                            children: [
                                                                              //minus button
                                                                              IconButton(
                                                                                onPressed: () {
                                                                                  _getdec();
                                                                                  updateqty(arr[index].cartId).then((value) => Cartview());
                                                                                  updateqty(arr[index].cartId).then((value) => Total());

                                                                                  setState(
                                                                                    () {},
                                                                                  );
                                                                                },
                                                                                icon: Icon(
                                                                                  Icons.remove,
                                                                                  color: Colors.black,
                                                                                  size: 20,
                                                                                ),
                                                                              ),
                                                                              //quantity button
                                                                              Card(
                                                                                child: Container(
                                                                                  decoration: BoxDecoration(
                                                                                      borderRadius: BorderRadius.circular(
                                                                                        7,
                                                                                      ),
                                                                                      color: Colors.white,
                                                                                      boxShadow: [
                                                                                        BoxShadow(
                                                                                          color: Colors.grey.withOpacity(0.2),
                                                                                          offset: Offset(3, 2),
                                                                                          blurRadius: 30,
                                                                                        )
                                                                                      ]),
                                                                                  height: 45,
                                                                                  width: 45,
                                                                                  child: Center(
                                                                                    child: Text(
                                                                                      val.toString(),
                                                                                      style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              //add button
                                                                              IconButton(
                                                                                onPressed: () {
                                                                                  _getin();

                                                                                  updateqty(arr[index].cartId).then((value) => Cartview());
                                                                                  updateqty(arr[index].cartId).then((value) => Total());

                                                                                  setState(() {});
                                                                                },
                                                                                icon: Icon(
                                                                                  Icons.add,
                                                                                  color: Colors.black,
                                                                                  size: 20,
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        //update button
                                                                        Container(
                                                                          child:
                                                                              InkWell(
                                                                            onTap:
                                                                                () {
                                                                              setState(
                                                                                () {},
                                                                              );
                                                                              Navigator.pop(context);

                                                                              Fluttertoast.showToast(msg: 'Quantity updated succussfully!');
                                                                            },
                                                                            child:
                                                                                Container(
                                                                              height: size.height * 0.07,
                                                                              width: double.infinity,
                                                                              child: Row(
                                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Text(
                                                                                    "Update",
                                                                                    style: TextStyle(
                                                                                      color: Colors.white,
                                                                                      fontWeight: FontWeight.bold,
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              decoration: BoxDecoration(
                                                                                borderRadius: BorderRadius.circular(10),
                                                                                color: eraPrimaryColor,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  );
                                                                });
                                                              },
                                                            );
                                                          },
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(
                                                height: size.height * 0.02,
                                              ),
                                              new Divider(),
                                              Container(
                                                padding: const EdgeInsets.only(
                                                    bottom: 8, right: 25),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    InkWell(
                                                      child: Text(
                                                        "Remove",
                                                        style: TextStyle(
                                                          fontSize: 14,
                                                          color:
                                                              eraPrimaryColor,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                      onTap: () async {
                                                        await showDialog(
                                                          builder: (ctxt) {
                                                            return AlertDialog(
                                                              shape:
                                                                  RoundedRectangleBorder(
                                                                side: BorderSide(
                                                                    color: Colors
                                                                        .white70,
                                                                    width: 1),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            18),
                                                              ),
                                                              title: Text(
                                                                "Remove Item",
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        18,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold),
                                                              ),
                                                              content: Text(
                                                                "Are you sure you want to remove this item?",
                                                                textAlign:
                                                                    TextAlign
                                                                        .justify,
                                                              ),
                                                              actions: [
                                                                Container(
                                                                  padding: EdgeInsets
                                                                      .only(
                                                                          bottom:
                                                                              15),
                                                                  child: Row(
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .spaceAround,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .center,
                                                                    children: [
                                                                      SizedBox(
                                                                        height: size.height *
                                                                            0.055,
                                                                        width: size.width *
                                                                            0.28,
                                                                        child:
                                                                            OutlinedButton(
                                                                          style:
                                                                              OutlinedButton.styleFrom(
                                                                            primary:
                                                                                Colors.black,
                                                                            backgroundColor:
                                                                                Colors.white,
                                                                            side:
                                                                                BorderSide(
                                                                              color: Colors.black,
                                                                              width: 1,
                                                                            ),
                                                                            shape:
                                                                                RoundedRectangleBorder(
                                                                              borderRadius: BorderRadius.circular(
                                                                                20,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          child:
                                                                              Text(
                                                                            'Cancel',
                                                                            style:
                                                                                TextStyle(
                                                                              color: Colors.black,
                                                                              fontWeight: FontWeight.bold,
                                                                            ),
                                                                          ),
                                                                          onPressed:
                                                                              () {
                                                                            Navigator.pop(context);
                                                                          },
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                        height: size.height *
                                                                            0.055,
                                                                        width: size.width *
                                                                            0.28,
                                                                        child:
                                                                            ElevatedButton(
                                                                          child:
                                                                              Text(
                                                                            "Remove",
                                                                            style:
                                                                                TextStyle(
                                                                              color: Colors.white,
                                                                              fontWeight: FontWeight.bold,
                                                                            ),
                                                                          ),
                                                                          style:
                                                                              ElevatedButton.styleFrom(
                                                                            onPrimary:
                                                                                Colors.white,
                                                                            primary:
                                                                                eraPrimaryColor,
                                                                            onSurface:
                                                                                Colors.grey,
                                                                            elevation:
                                                                                0,
                                                                            minimumSize:
                                                                                Size(150, 50),
                                                                            shadowColor:
                                                                                Colors.grey.shade100,
                                                                            shape:
                                                                                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                                                                          ),
                                                                          onPressed:
                                                                              () {
                                                                            cartdlt(arr[index].cartId).then((value) =>
                                                                                Cartview());
                                                                            cartdlt(arr[index].cartId).then((value) =>
                                                                                Total());

                                                                            setState(() {});

                                                                            Navigator.pop(context);

                                                                            Fluttertoast.showToast(
                                                                              msg: 'Cart item removed succussfully!',
                                                                            );
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ],
                                                            );
                                                          },
                                                          context: context,
                                                        );
                                                      },
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  });
                        } else {
                          return Column(
                            children: [
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.25,
                              ),
                              Center(child: Loading()),
                            ],
                          );
                        }
                      }),
                ],
              ),
            )
          : ConnectionCheck(),
      //Checkout card
      bottomNavigationBar: FutureBuilder(
        future: Total(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            List<TotalClass> arr = snapshot.data.totalClass;
            return ListView.builder(
                shrinkWrap: true,
                itemCount: arr.length,
                itemBuilder: (context, index) {
                  if (arr[index].count == 0) {
                    if (_isInternetOn = false) {
                      return Container();
                    }
                    return Container();
                  } else {
                    return Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          topRight: Radius.circular(10),
                        ),
                        boxShadow: [
                          BoxShadow(
                            offset: Offset(0, -15),
                            blurRadius: 20,
                            color: Color(0xFFDADADA).withOpacity(0.15),
                          ),
                        ],
                      ),
                      child: SafeArea(
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  //first column
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      Text.rich(
                                        TextSpan(
                                          text: "Subtotal:\n",
                                          style: TextStyle(
                                            fontSize: 14,
                                          ),
                                          children: [
                                            TextSpan(
                                              text: '\$' +
                                                  arr[index]
                                                      .totalPrice
                                                      .toString(),
                                              style: TextStyle(
                                                fontSize: 23,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.grey[850],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  //second column
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: [
                                      //credit point section
                                      Row(
                                        children: [
                                          Text("Total entry points:"),
                                          const SizedBox(width: 5),
                                          Text(
                                            arr[index].totalEnt.toString(),
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: size.height * 0.015),
                                      //checkout button
                                      SizedBox(
                                        height: size.height * 0.065,
                                        width: size.width * 0.4,
                                        child: ElevatedButton(
                                          onPressed: () async {
                                            final prefs =
                                                await SharedPreferences
                                                    .getInstance();
                                            String userid =
                                                prefs.getString('userId');
                                            print(userid.toString());

                                            String url =
                                                'https://eradealz.com/api/checkout.php?' +
                                                    'id=' +
                                                    userid;

                                            await Navigator.push(
                                                context,
                                                CustomPageRoute(
                                                    child: Payment(
                                                  url: url,
                                                )));
                                          },
                                          style: ElevatedButton.styleFrom(
                                            primary: eraPrimaryColor,
                                            elevation: 0,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(30),
                                            ),
                                            padding: EdgeInsets.all(10),
                                          ),
                                          child: Text(
                                            'Continue',
                                            style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }
                });
          } else {
            return Column(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.5,
                ),
                Center(child: Loading()),
              ],
            );
          }
        },
      ),
    );
  }

  Future<void> refreshList() async {
    refreshKey.currentState.show(atTop: false);
    await Future.delayed(Duration(seconds: 2));
    setState(() {
      Cartview();
      Total();
    });
    return null;
  }
}
