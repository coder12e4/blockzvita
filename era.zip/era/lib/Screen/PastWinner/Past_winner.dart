import 'dart:convert';
import 'package:eradealz/Model/Pastwinners_Class.dart';
import 'package:eradealz/Widgets/connection_check.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'detailsPage.dart';
import 'package:shimmer/shimmer.dart';

import 'package:connectivity/connectivity.dart'; //connectivity


class Past extends StatefulWidget {
  const Past({Key key}) : super(key: key);

  @override
  _PastState createState() => _PastState();
}

var refreshKey=GlobalKey<RefreshIndicatorState>();

class _PastState extends State<Past> {

  bool _isInternetOn = true;

  // ignore: missing_return
  Future<PastwinnersApi> getdata() async {
    String url = "https://eradealz.com/api/winner.php/fetch_winner()";

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Success");

      return PastwinnersApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // ignore: todo
    // TODO: implement initState
    super.initState();
    getdata();
    checkConnection(); //check internet is on or not
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      //appbar
      appBar: AppBar(
        automaticallyImplyLeading: false,
        iconTheme: IconThemeData(color: Colors.black),
        title: Container(
          child: Image.asset(
            "images/logo2.png",
            height: 48,
            width: 140,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      //body
      body: _isInternetOn ? RefreshIndicator(
        key: refreshKey,
        onRefresh: refreshList,
        child: ListView(
          physics: ScrollPhysics(),
          shrinkWrap: true,
          children: [
            SizedBox(height: size.height * 0.03),
            //header part
            Row(
              children: [
                SizedBox(width: size.width * 0.05),
                Image.asset(
                  "images/icon3.jpg",
                  height: 40,
                  width: 40,
                ),
                SizedBox(width: size.width * 0.06),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Past Winners",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFec1c24),
                          fontSize: 20,),
                    ),
                  ],
                ),
              ],
            ),

            SizedBox(height: size.height * 0.02),

            FutureBuilder(
                future: getdata(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    List<Item> arr = snapshot.data.items;
                    return ListView.builder(
                        physics: ScrollPhysics(),
                        itemCount: arr.length,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                CustomPageRoute(
                                  child: PastDetails(
                                    Id: arr[index].id,
                                  ),
                                ),
                              );
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 10,
                              ),
                              child: Container(
                                height: 120,
                                decoration: BoxDecoration(
                                  shape: BoxShape.rectangle,
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.white,
                                    ),
                                  ],
                                ),
                                child: Container(
                                  padding: EdgeInsets.symmetric(horizontal: 15,vertical: 5),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          //image col
                                          ClipRRect(
                                            borderRadius: BorderRadius.circular(1),
                                            child: Container(
                                              height: size.height * 0.12,
                                              width: size.width * 0.35,
                                              child: CachedNetworkImage(
                                                imageUrl: arr[index].winnerPhoto.toString(),
                                                fit: BoxFit.fill,
                                                placeholder: (context, url) => Shimmer.fromColors(
                                                  baseColor: Colors.grey.shade200,
                                                  highlightColor: Colors.grey.shade50,
                                                  child: ClipRRect(
                                                      borderRadius: BorderRadius.circular(1),
                                                      child: Container(
                                                        height: size.height * 0.12,
                                                        width: size.width * 0.35,
                                                        color: Colors.grey.shade100,
                                                      )),
                                                ),
                                                errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                                              ),
                                            ),
                                          ),



                                          SizedBox(width: size.width * 0.05),
                                          //details col
                                          Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              RichText(
                                                text: TextSpan(
                                                  style: TextStyle(fontSize: 15),
                                                  children: <TextSpan>[
                                                    TextSpan(
                                                      text: "#",
                                                      style: TextStyle(
                                                        color: eraTextColor,
                                                      ),
                                                    ),
                                                    TextSpan(
                                                      text: arr[index].raffleId,
                                                      style: TextStyle(
                                                        color: eraPrimaryColor,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              // SizedBox(
                                              //     height: size.height * 0.015),
                                              Text(
                                                arr[index].offer,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: eraMainTextColor,
                                                  fontSize: 16,
                                                ),
                                              ),
                                              // SizedBox(
                                              //     height: size.height * 0.01),
                                              Text(
                                                arr[index].userName,
                                                style: TextStyle(
                                                  color: eraTextColor,
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        });
                  } else {
                    return Column(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.35,
                        ),
                        Center(child: Loading()),
                      ],
                    );
                  }
                }),
          ],
        ),
      ) : ConnectionCheck(),
    );
  }
  void checkConnection() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      setState(() {
        _isInternetOn = false;
      });
    }
  }
  Future<void> refreshList() async{
    refreshKey.currentState.show(atTop: false);
    await Future.delayed(Duration(seconds: 2));
    setState(() {
      getdata();
    });
    return null;
  }
}
