import 'dart:convert';
import 'package:eradealz/Model/WinnerDetails_Class.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';

// ignore: must_be_immutable
class PastDetails extends StatefulWidget {
  String Id;
  PastDetails({Key key, this.Id});

  // const PastDetails({Key key}) : super(key: key);

  @override
  _PastDetailsState createState() => _PastDetailsState();
}

class _PastDetailsState extends State<PastDetails> {
  Future<WinnersdetailsApi> getdata() async {
    String url =
        "https://eradealz.com/api/winner_inner.php?" + "id" "=" + widget.Id;

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("past details Success");

      return WinnersdetailsApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        title: Container(
          child: Image.asset(
            "images/logo2.png",
            height: 48,
            width: 140,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      body: ListView(
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        children: [
          SizedBox(height: size.height * 0.03),
          FutureBuilder(
            future: getdata(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                List<Item> arr = snapshot.data.items;

                return ListView.builder(
                    physics: BouncingScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: arr.length,
                    itemBuilder: (context, index) {
                      return ListView(
                        shrinkWrap: true,
                        physics: BouncingScrollPhysics(),
                        children: [
                          //image
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: size.height * 0.01),
                                Row(
                                  children: [
                                    Text(
                                      arr[index].offer,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black,
                                          fontSize: 17),
                                    ),
                                    SizedBox(width: size.width * 0.5),
                                    Text(
                                      arr[index].time.toString(),
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Colors.red,
                                          fontSize: 10),
                                    ),
                                  ],
                                ),
                                SizedBox(height: size.height * 0.009),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.person_outlined,
                                      color: Colors.grey.shade600,
                                      size: 20,
                                    ),
                                    SizedBox(width: size.width * 0.02),
                                    Text(arr[index].userName)
                                  ],
                                ),
                                SizedBox(height: size.height * 0.01),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.card_giftcard_outlined,
                                      color: Colors.grey.shade600,
                                      size: 20,
                                    ),
                                    SizedBox(width: size.width * 0.02),
                                    Text(arr[index].raffleId)
                                  ],
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: size.height * 0.02),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(1),
                            child: Container(
                              height: size.height * 0.3,
                              width: size.width * 0.5,
                              child: CachedNetworkImage(
                                imageUrl: arr[index].winnerPhoto,
                                fit: BoxFit.fill,
                                placeholder: (context, url) => Shimmer.fromColors(
                                  baseColor: Colors.grey.shade200,
                                  highlightColor: Colors.grey.shade50,
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(1),
                                      child: Container(
                                        height: size.height * 0.3,
                                        width: size.width * 0.5,
                                        color: Colors.grey.shade100,
                                      )),
                                ),
                                errorWidget: (context, url, error) =>
                                    Image.asset(
                                  "images/ina.jpg",
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: size.height * 0.02),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(1),
                            child: Container(
                              height: size.height * 0.3,
                              width: size.width * 0.5,
                              child: CachedNetworkImage(
                                imageUrl: arr[index].winnerPhoto1,
                                fit: BoxFit.fill,
                                placeholder: (context, url) => Shimmer.fromColors(
                                  baseColor: Colors.grey.shade200,
                                  highlightColor: Colors.grey.shade50,
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(1),
                                      child: Container(
                                        height: size.height * 0.3,
                                        width: size.width * 0.5,
                                        color: Colors.grey.shade100,
                                      )),
                                ),
                                errorWidget: (context, url, error) =>
                                    Image.asset(
                                  "images/ina.jpg",
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: size.height * 0.02),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(1),
                            child: Container(
                              height: size.height * 0.3,
                              width: size.width * 0.5,
                              child: CachedNetworkImage(
                                imageUrl: arr[index].winnerPhoto2,
                                fit: BoxFit.fill,
                                placeholder: (context, url) => Shimmer.fromColors(
                                  baseColor: Colors.grey.shade200,
                                  highlightColor: Colors.grey.shade50,
                                  child: ClipRRect(
                                      borderRadius: BorderRadius.circular(1),
                                      child: Container(
                                        height: size.height * 0.3,
                                        width: size.width * 0.5,
                                        color: Colors.grey.shade100,
                                      )),
                                ),
                                errorWidget: (context, url, error) =>
                                    Image.asset(
                                  "images/ina.jpg",
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: size.height * 0.06),
                        ],
                      );
                    });
              } else {
                return Column(
                  children: [
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.35,
                    ),
                    Center(child: Loading()),
                  ],
                );
              }
            },
          ),
        ],
      ),
    );
  }
}
