import 'package:eradealz/Components/bottomNav.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:flutter/material.dart';

class OrderComplete extends StatefulWidget {
  @override
  _OrderCompleteState createState() => _OrderCompleteState();
}

class _OrderCompleteState extends State<OrderComplete> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
      ),
      body: ListView(
        children: [
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 60),
                child: Center(
                    child: Icon(
                  Icons.shopping_bag_outlined,
                  size: 200,
                )),
              ),
              Container(
                child: Column(
                  children: [
                    Container(
                      child: Text(
                        "Your Order is placed",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 25),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                        child: Container(
                      height: 50,
                      width: 200,
                      child: Text(
                        "It is now very easy to search the best quality among all the products on the internet!",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 10,
                            color: Colors.grey),
                      ),
                    ))
                  ],
                ),
              ),
              SizedBox(
                height: 70,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10.0),
                child: SizedBox(
                  height: 45, //height of button
                  width: size.width * 0.8,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Color(0xFFec1c24),
                      elevation: 3,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      padding: EdgeInsets.all(10),
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          CustomPageRoute(child: BottomNav()));
                    },
                    child: Text(
                      "Continue Shoping",
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                    ),
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
