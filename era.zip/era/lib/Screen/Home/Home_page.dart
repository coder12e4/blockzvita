import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:connectivity/connectivity.dart'; //connectivity
import 'package:eradealz/Model/Product_Class.dart';
import 'package:eradealz/Screen/Home/Category_page.dart';
import 'package:eradealz/Screen/ProductDetails/productdetails.dart';
import 'package:eradealz/Widgets/Badge.dart';
import 'package:eradealz/Widgets/connection_check.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';

import 'Banner_page.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

var refreshKey = GlobalKey<RefreshIndicatorState>();

class _HomeState extends State<Home> {
  bool _isInternerOn = true;

  Future<Products> getdata() async {
    String url = "https://eradealz.com/api.php/fetch_product()";

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Success");

      return Products.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
    checkConnection();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: Container(
          child: Image.asset(
            "images/logo2.png",
            height: 48,
            width: 140,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: true,
        automaticallyImplyLeading: false,
        actions: [
          Appbarbadge(),
        ],
      ),
      body: _isInternerOn
          ? RefreshIndicator(
              key: refreshKey,
              onRefresh: refreshList,
              child: ListView(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: BouncingScrollPhysics(),
                children: [
                  //Category
                  Container(
                    height: 80,
                    color: Color(0xFFec1c24),
                    child: Category(),
                  ),

                  //Banner
                  FetchBanner(),

                  SizedBox(height: size.height * 0.02),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    child: Container(
                      child: Row(
                        children: [
                          Text(
                            "All Products",
                            style: TextStyle(
                              fontSize: 17,
                              color: Colors.black87,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  FutureBuilder(
                    future: getdata(),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        List<Item> products = snapshot.data.items;
                        return GridView.builder(
                          physics: ScrollPhysics(),
                          itemCount: products.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            childAspectRatio: 0.7,
                            crossAxisCount: 2,
                            mainAxisSpacing: 10,
                            crossAxisSpacing: 3,
                          ),
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  CustomPageRoute(
                                    child: ProductDetails(
                                      pid: products[index].id,
                                      oid: products[index].offerId,
                                    ),
                                  ),
                                );
                              },
                              child: Card(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(1),
                                  child: Container(
                                    child: Column(
                                      children: [
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(1),
                                          child: Container(
                                            height: size.height * 0.24,
                                            width: size.width * 0.4,
                                            child: CachedNetworkImage(
                                              imageUrl: products[index]
                                                  .photo
                                                  .toString(),
                                              fit: BoxFit.fill,
                                              placeholder: (context, url) =>
                                                  Shimmer.fromColors(
                                                baseColor: Colors.grey.shade200,
                                                highlightColor:
                                                    Colors.grey.shade50,
                                                child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            1),
                                                    child: Container(
                                                      height:
                                                          size.height * 0.24,
                                                      width: size.width * 0.4,
                                                      color:
                                                          Colors.grey.shade100,
                                                    )),
                                              ),
                                              errorWidget:
                                                  (context, url, error) =>
                                                      Image.asset(
                                                "images/ina.jpg",
                                                fit: BoxFit.fill,
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(height: size.height * 0.009),
                                        Text(products[index].name),
                                        SizedBox(height: size.height * 0.01),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            SizedBox(width: size.width * 0.04),
                                            Text(
                                              "INR " + products[index].price,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(17),
                                                  color: Colors.teal.shade300),
                                              child: Center(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(5),
                                                  child: Text(
                                                    products[index].entries +
                                                        " Enteries",
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      } else {
                        return Column(
                          children: [
                            SizedBox(
                              height: MediaQuery.of(context).size.height * 0.15,
                            ),
                            Center(child: Loading()),
                          ],
                        );
                      }
                    },
                  ),
                ],
              ),
            )
          : ConnectionCheck(),
    );
  }

  void checkConnection() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      setState(() {
        _isInternerOn = false;
      });
    }
  }

  Future<void> refreshList() async {
    refreshKey.currentState.show(atTop: false);
    await Future.delayed(Duration(seconds: 2));
    setState(() {
      getdata();
    });
    return null;
  }
}
