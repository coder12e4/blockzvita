import 'dart:convert';

import 'package:eradealz/Model/Category_Class.dart';
import 'package:eradealz/Screen/Subsategory/Subcategory.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Category extends StatefulWidget {
  const Category({Key key}) : super(key: key);

  @override
  _CategoryState createState() => _CategoryState();
}

class _CategoryState extends State<Category> {

  Future<CategoryApi> getdata() async {
    String url = "https://eradealz.com/api/category.php";

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Success");

      return CategoryApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return ListView(
      scrollDirection: Axis.horizontal,
      shrinkWrap: true,
      physics: BouncingScrollPhysics(),
      children: [
        FutureBuilder(
            future: getdata(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                List<Item> arr = snapshot.data.items;
                return ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    physics: BouncingScrollPhysics(),
                    itemCount: arr.length,
                    itemBuilder: (context, index) {
                      return Row(
                        children: [
                          // ignore: deprecated_member_use
                          FlatButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                CustomPageRoute(
                                  child: subcategory(
                                    Id: arr[index].id,
                                    Name: arr[index].name,
                                  ),
                                ),
                              );
                            },
                            child: Column(
                              children: [
                                SizedBox(height: size.height * 0.02),
                                Image.network(
                                  arr[index].photo,
                                  height: 30,
                                  width: 30,
                                  loadingBuilder:(BuildContext context, Widget child,ImageChunkEvent loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return Center(
                                      child: Loading(),
                                    );
                                  },
                                ),
                                SizedBox(height: size.height * 0.01),
                                Text(
                                  arr[index].name,
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: eraBackgroundColor
                                  ),
                                ),
                              ],
                            ),
                            splashColor: Colors.white60,
                          ),
                        ],
                      );
                    });
              } else {
                return Row(
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.45,
                    ),
                    Loading(),
                  ],
                );
              }
            },),
      ],
    );
  }
}