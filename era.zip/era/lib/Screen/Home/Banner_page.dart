import 'dart:convert';
import 'package:eradealz/Model/fetchBanner_Class.dart';
import 'package:eradealz/Screen/CurrentCapaign/Current_campagns.dart';
import 'package:eradealz/Screen/CurrentCapaign/detailsPage.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';

class FetchBanner extends StatefulWidget {
  const FetchBanner({Key key}) : super(key: key);

  @override
  _FetchBannerState createState() => _FetchBannerState();
}

class _FetchBannerState extends State<FetchBanner> {
  Future<BannerApi> getdata() async {
    String url =
        "https://eradealz.com/api/fetch_banner.php";

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Success");

      return BannerApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return FutureBuilder(
        future: getdata(),
        builder: (context, snapshot) {

          if (snapshot.hasData) {
            List<Item> arr =snapshot.data.items;
                  return GestureDetector(
                    onTap: (){
                      Navigator.push(
                        context,
                        CustomPageRoute(child: campaigns(),),
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.27,
                      child: Carousel(
                        boxFit: BoxFit.fill,
                        images: [
                          for (var i = 0; i < arr.length; i++)
                            CachedNetworkImage(
                              imageUrl: arr[i].photo,
                              fit: BoxFit.fill,
                              placeholder: (context, url) => Shimmer.fromColors(
                                baseColor: Colors.grey.shade200,
                                highlightColor: Colors.grey.shade50,
                                child: ClipRRect(
                                    borderRadius: BorderRadius.circular(1),
                                    child: Container(
                                      width: MediaQuery.of(context).size.width,
                                      height: MediaQuery.of(context).size.height * 0.27,
                                      color: Colors.grey.shade100,
                                    )),
                              ),
                              errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                            ),


                        ],
                        autoplay: true,
                        autoplayDuration: Duration(seconds: 3),
                        indicatorBgPadding: 0,
                        dotBgColor: Colors.white,
                        dotColor: Colors.grey.shade700,
                        dotSize: 5.0,
                        showIndicator: true,
                        dotIncreasedColor: Colors.red.shade400,
                        dotSpacing: 8,
                      ),
                    ),
                  );
          }
          else {
            return
            Column(
              children: [
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.12,
                ),
                Center(child: Loading()),
              ],
            );
          }
        }
        );
  }
}

