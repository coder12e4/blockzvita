import 'package:eradealz/Widgets/connection_check.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fdottedline/fdottedline.dart';

import 'package:connectivity/connectivity.dart'; //connectivity

class Refer extends StatefulWidget {
  const Refer({Key key}) : super(key: key);

  @override
  _ReferState createState() => _ReferState();
}

class _ReferState extends State<Refer> {
  SharedPreferences prefs;
  String rId;

  bool _isInternetOn = true;

  void getReferalData() async {
    final prefs = await SharedPreferences.getInstance();
    String r = prefs.getString('rflcode');

    setState(() {
      rId = r;
    });
  }

  void checkConnection() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      setState(() {
        _isInternetOn = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    getReferalData();
    checkConnection(); //check internet is on or not
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      //Appbar
      appBar: AppBar(
        automaticallyImplyLeading: false,
        iconTheme: IconThemeData(color: Colors.black),
        title: Container(
          child: Image.asset(
            "images/logo2.png",
            height: 48,
            width: 140,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: true,
      ),
      //body
      body: _isInternetOn
          ? SafeArea(
              child: SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      // image
                      SizedBox(
                        height: size.height * 0.3,
                        width: size.width * 0.7,
                        child: Container(
                          child: Image.asset(
                            "images/refer.png",
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: Text(
                          'INVITE YOUR FRIENDS',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: eraMainTextColor,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Text(
                          'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: eraTextColor,
                            fontSize: 15,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      // referal code box
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 30),
                        child: FDottedLine(
                          color: eraTextColor,
                          strokeWidth: 1.5,
                          dottedLength: 8.0,
                          space: 5.0,
                          corner: FDottedLineCorner.all(10.0),
                          child: Container(
                            decoration: BoxDecoration(
                                // color: Colors.red[50]
                                ),
                            child: Container(
                              margin: EdgeInsets.all(15),
                              child: Text(
                                'https://eradealz.com/register.php?id=' +
                                    rId.toString(),
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 16,
                                  color: eraMainTextColor,
                                  fontWeight: FontWeight.bold,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      //invite button
                      Container(
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            onPrimary: Colors.white,
                            primary: eraPrimaryColor,
                          ),
                          child: Container(
                            margin: EdgeInsets.all(10),
                            child: Text(
                              "Invite",
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          onPressed: () {
                            Share.share(
                                'https://eradealz.com/register.php?id=' +
                                    rId.toString());
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
          : ConnectionCheck(),
    );
  }
}
