import 'dart:convert';
import 'package:eradealz/Model/AboutUs_Class.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class About extends StatefulWidget {
  const About({Key key}) : super(key: key);

  @override
  _AboutState createState() => _AboutState();
}

class _AboutState extends State<About> {
  Future<AboutUs> getdata() async {
    String url = "https://eradealz.com/api/about_us.php";

    var responce = await http.post(url);
    if (responce.statusCode == 200) {
      print("Success");

      return AboutUs.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          'About',
          style: appBarStyle,
        ),
      ),
      body: ListView(
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        children: [
          SizedBox(height: size.height * 0.03),
          FutureBuilder(
              future: getdata(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<Item> arr = snapshot.data.items;
                  return ListView.builder(
                      itemCount: arr.length,
                      shrinkWrap: true,
                      physics: BouncingScrollPhysics(),
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(left: 15, right: 15),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                arr[index].about,
                                textAlign: TextAlign.justify,
                                style: TextStyle(
                                  height: 1.5,
                                  fontSize: 14,
                                ),
                                
                              ),
                              SizedBox(
                                height: size.height * 0.1,
                              )
                            ],
                          ),
                        );
                      });
                } else {
                  return Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      Center(child: Loading()),
                    ],
                  );
                }
              }),
        ],
      ),
    );
  }
}
