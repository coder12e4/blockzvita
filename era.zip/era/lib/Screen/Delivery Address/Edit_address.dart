import 'dart:convert';
import 'package:eradealz/Model/Updateaddress_Class.dart';
import 'package:eradealz/Model/Viewaddress_Class.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:eradealz/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'View_address.dart';

class Editaddress extends StatefulWidget {
  const Editaddress({Key key}) : super(key: key);

  @override
  _EditaddressState createState() => _EditaddressState();
}

class _EditaddressState extends State<Editaddress> {
  Future future;

  final _formKey = GlobalKey<FormState>();

  TextEditingController houseNameController = new TextEditingController();
  TextEditingController streetnumberController = new TextEditingController();
  TextEditingController areaController = new TextEditingController();
  TextEditingController cityController = new TextEditingController();
  TextEditingController countryController = new TextEditingController();
  TextEditingController pincodeController = new TextEditingController();
  TextEditingController stateController = new TextEditingController();
  TextEditingController phoneController = new TextEditingController();

  void editAddress(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');

    var client = http.Client();

    String houseName = houseNameController.text;
    String streetNumber = streetnumberController.text;
    String area = areaController.text;
    String city = cityController.text;
    String country = countryController.text;
    String pinCode = pincodeController.text;
    String state = stateController.text;
    String phone = phoneController.text;

    var jsonresponse = await client.get(
        "https://eradealz.com/api/update_address.php?" +
            "id=" +
            userid +
            "&housename=" +
            houseName +
            "&streetno=" +
            streetNumber +
            "&area=" +
            area +
            "&city=" +
            city +
            "&country=" +
            country +
            "&pincode=" +
            pinCode +
            "&state=" +
            state +
            "&phone=" +
            phone);

    if (jsonresponse.statusCode == 200) {
      // ignore: await_only_futures
      var response =
          await UpdateaddressApi.fromJson(jsonDecode(jsonresponse.body));

      print(response.uitems);

      Fluttertoast.showToast(
        msg: "Address updated successfully",
        textColor: Colors.white,
      );

      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => DeliveryAddress()));
    } else {
      print('update failed');
    }
  }

  Future<ViewaddressApi> fetchShippingAddress() async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');

    String url = "https://eradealz.com/api/get_address.php?" + "id=" + userid;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print(responce.body);
      print("shipping address view success");

      return ViewaddressApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  
void dispose() {

}
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    future = fetchShippingAddress();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context,
                CustomPageRoute(child: DeliveryAddress()));
          },
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
        ),
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          'Edit Address',
          style: appBarStyle,
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
                child: Container(
                  child: FutureBuilder(
                      future: future,
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          List<Item> arr = snapshot.data.items;

                          houseNameController =
                              new TextEditingController(text: arr[0].housename);
                          streetnumberController =
                              new TextEditingController(text: arr[0].streetno);
                          areaController =
                              new TextEditingController(text: arr[0].area);
                          cityController =
                              new TextEditingController(text: arr[0].city);
                          stateController =
                              new TextEditingController(text: arr[0].state);
                          countryController =
                              new TextEditingController(text: arr[0].country);
                          pincodeController =
                              new TextEditingController(text: arr[0].pincode);
                          phoneController =
                              new TextEditingController(text: arr[0].phone);

                          return Form(
                            key: _formKey,
                            child: Column(
                              children: <Widget>[
                                //house name
                                TextFormField(
                                  controller: houseNameController,
                                  textCapitalization:
                                      TextCapitalization.sentences,
                                  decoration: new InputDecoration(
                                    hintText: '',
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: eraPrimaryColor),
                                    ),
                                    labelText: 'House Name',
                                  ),
                                  // onSaved: (newValue) =>
                                  //     houseNameController.text = newValue,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your house name";
                                    } else {
                                      return null;
                                    }
                                  },
                                ),
                                SizedBox(height: size.height * 0.01),
                                //Street number
                                TextFormField(
                                  controller: streetnumberController,
                                  keyboardType: TextInputType.number,
                                  decoration: new InputDecoration(
                                    hintText: "",
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: eraPrimaryColor),
                                    ),
                                    labelText: 'Street Number',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your street number";
                                    } else {
                                      return null;
                                    }
                                  },
                                ),
                                SizedBox(height: size.height * 0.01),
                                // Area
                                TextFormField(
                                  controller: areaController,
                                  textCapitalization:
                                      TextCapitalization.sentences,
                                  decoration: new InputDecoration(
                                    hintText: "",
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: eraPrimaryColor),
                                    ),
                                    labelText: 'Area',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your area";
                                    } else {
                                      return null;
                                    }
                                  },
                                ),
                                SizedBox(height: size.height * 0.01),
                                // City
                                TextFormField(
                                  controller: cityController,
                                  textCapitalization:
                                      TextCapitalization.sentences,
                                  decoration: new InputDecoration(
                                    hintText: "",
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: eraPrimaryColor),
                                    ),
                                    labelText: 'City',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your city";
                                    } else {
                                      return null;
                                    }
                                  },
                                ),
                                SizedBox(height: size.height * 0.01),
                                // State
                                TextFormField(
                                  controller: stateController,
                                  textCapitalization:
                                      TextCapitalization.sentences,
                                  decoration: new InputDecoration(
                                    hintText: "",
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: eraPrimaryColor),
                                    ),
                                    labelText: 'State',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your State";
                                    } else {
                                      return null;
                                    }
                                  },
                                ),
                                SizedBox(height: size.height * 0.01),
                                // Country
                                TextFormField(
                                  controller: countryController,
                                  textCapitalization:
                                      TextCapitalization.sentences,
                                  decoration: new InputDecoration(
                                    hintText: "",
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: eraPrimaryColor),
                                    ),
                                    labelText: 'Country',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your country";
                                    } else {
                                      return null;
                                    }
                                  },
                                ),
                                SizedBox(height: size.height * 0.01),
                                // Pin code
                                TextFormField(
                                  controller: pincodeController,
                                  maxLength: 6,
                                  keyboardType: TextInputType.number,
                                  decoration: new InputDecoration(
                                    hintText: "",
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: Colors.grey),
                                    ),
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: eraPrimaryColor),
                                    ),
                                    labelText: 'Pin Code',
                                  ),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your PIN code";
                                    } else if (value.length != 6) {
                                      return "Please enter valid PIN code";
                                    } else {
                                      return null;
                                    }
                                  },
                                ),
                                SizedBox(height: size.height * 0.01),
                                //mobile number
                                TextFormField(
                                  controller: phoneController,
                                  maxLength: 10,
                                  keyboardType: TextInputType.phone,
                                  decoration: new InputDecoration(
                                    hintText: "",
                                    prefixText: "+91 ",
                                    focusedBorder: UnderlineInputBorder(
                                      borderSide:
                                          BorderSide(color: eraPrimaryColor),
                                    ),
                                    enabledBorder: new UnderlineInputBorder(
                                      borderSide:
                                          new BorderSide(color: Colors.grey),
                                    ),
                                    labelText: 'Mobile',
                                  ),
                                  validator: (value) {
                                    String patttern =
                                        r'(^(?:[+0]9)?[0-9]{10,12}$)';
                                    RegExp regExp = new RegExp(patttern);
                                    if (value == null || value.isEmpty) {
                                      return "Please enter your mobile number";
                                    } else if (!regExp.hasMatch(value) ||
                                        value.length != 10) {
                                      return "Please enter valid mobile number";
                                    } else {
                                      return null;
                                    }
                                  },
                                ),
                                SizedBox(height: size.height * 0.04),
                                //button
                                SizedBox(
                                  height: size.height * 0.08,
                                  width: size.width * 0.7,
                                  child: ElevatedButton(
                                    onPressed: () {
                                      if (_formKey.currentState.validate()) {
                                        editAddress(context);
                                      }
                                    },
                                    style: ElevatedButton.styleFrom(
                                      primary: eraPrimaryColor,
                                      onPrimary: Colors.white,
                                      onSurface: Colors.grey,
                                      elevation: 3,
                                      shadowColor: Colors.grey,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(30),
                                      ),
                                    ),
                                    child: Text(
                                      'Save',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 15,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        } else {
                          return Column(
                            children: [
                              SizedBox(
                                height:
                                    MediaQuery.of(context).size.height * 0.35,
                              ),
                              Center(child: Loading()),
                            ],
                          );
                        }
                      }),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
