import 'dart:convert';
import 'package:eradealz/Model/Viewaddress_Class.dart';
import 'package:eradealz/Screen/Delivery%20Address/Add_address.dart';
import 'package:eradealz/Screen/Profile/Profile_page.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'Edit_address.dart';

class DeliveryAddress extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        //appbar
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.black),
          automaticallyImplyLeading: true,
          backgroundColor: Colors.white,
          title: Text('Shipping Address', style: appBarStyle),
        ),
        //body
        body: SavedAddress(),
      ),
    );
  }
}

class SavedAddress extends StatefulWidget {
  @override
  _SavedAddressState createState() => _SavedAddressState();
}

class _SavedAddressState extends State<SavedAddress> {
  Future<ViewaddressApi> fetchShippingAddress() async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');

    String url = "https://eradealz.com/api/get_address.php?" + "id=" + userid;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print(responce.body);
      print("shipping address view success");

      return ViewaddressApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchShippingAddress();
  }

  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      body: ListView(
        physics: BouncingScrollPhysics(),
        children: <Widget>[
          FutureBuilder(
              future: fetchShippingAddress(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<Item> arr = snapshot.data.items;
                  return arr.isEmpty
                      ? Column(
                          children: [
                            SizedBox(height: size.height * 0.05),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                ElevatedButton.icon(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                AddAddress()));
                                  },
                                  icon: Icon(
                                    Icons.add,
                                    color: Colors.white,
                                  ),
                                  label: Text("Add address"),
                                  style: ElevatedButton.styleFrom(
                                    primary: eraPrimaryColor,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: size.height * 0.02),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  "NO SAVED ADDRESS",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.grey,
                                      fontSize: 10),
                                ),
                              ],
                            )
                          ],
                        )
                      : ListView.builder(
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          physics: BouncingScrollPhysics(),
                          itemCount: arr.length,
                          itemBuilder: (context, index) {
                            return Container(
                              padding: EdgeInsets.symmetric(
                                  vertical: 20, horizontal: 20),
                              child: Column(
                                children: [
                                  //House name
                                  TextField(
                                    controller: TextEditingController(
                                      text: arr[0].housename.toString(),
                                    ),
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      labelText: 'House Name',
                                      labelStyle:
                                          TextStyle(color: eraMainTextColor),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.025),
                                  // street number
                                  TextField(
                                    controller: TextEditingController(
                                      text: arr[0].streetno.toString(),
                                    ),
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      labelText: 'Street No.',
                                      labelStyle:
                                          TextStyle(color: eraMainTextColor),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.025),
                                  // Area
                                  TextField(
                                    controller: TextEditingController(
                                      text: arr[0].area.toString(),
                                    ),
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      labelText: 'Area',
                                      labelStyle:
                                          TextStyle(color: eraMainTextColor),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.025),
                                  //city
                                  TextField(
                                    controller: TextEditingController(
                                      text: arr[0].city.toString(),
                                    ),
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      labelText: 'City',
                                      labelStyle:
                                          TextStyle(color: eraMainTextColor),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.025),
                                  //state
                                  TextField(
                                    controller: TextEditingController(
                                      text: arr[0].state.toString(),
                                    ),
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      labelText: 'State',
                                      labelStyle:
                                          TextStyle(color: eraMainTextColor),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.025),

                                  TextField(
                                    controller: TextEditingController(
                                      text: arr[0].country.toString(),
                                    ),
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      labelText: 'Country',
                                      labelStyle:
                                          TextStyle(color: eraMainTextColor),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.025),
                                  // pin code
                                  TextField(
                                    controller: TextEditingController(
                                      text: arr[0].pincode.toString(),
                                    ),
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      labelText: 'PIN Code',
                                      labelStyle:
                                          TextStyle(color: eraMainTextColor),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: size.height * 0.025),
                                  //phone number
                                  TextField(
                                    controller: TextEditingController(
                                      text: arr[0].phone.toString(),
                                    ),
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      labelText: 'Mobile Number',
                                      labelStyle:
                                          TextStyle(color: eraMainTextColor),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide:
                                            BorderSide(color: eraMainTextColor),
                                      ),
                                    ),
                                  ),

                                  SizedBox(height: size.height * 0.04),

                                  SizedBox(
                                    height: size.height * 0.08,
                                    width: size.width * 0.7,
                                    child: ElevatedButton(
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            CustomPageRoute(
                                                child:
                                                    Editaddress()));
                                      },
                                      style: ElevatedButton.styleFrom(
                                        primary: eraPrimaryColor,
                                        onPrimary: Colors.white,
                                        onSurface: Colors.grey,
                                        elevation: 3,
                                        shadowColor: Colors.grey,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(30),
                                        ),
                                      ),
                                      child: Text(
                                        'Edit Address',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  ),

                                  SizedBox(height: size.height * 0.04),
                                ],
                              ),
                            );
                          },
                        );
                } else {
                  return Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      Center(child: Loading()),
                    ],
                  );
                }
              }),
        ],
      ),
    );
  }
}
