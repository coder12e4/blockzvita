import 'package:eradealz/Model/Resetpass_Class.dart';
import 'package:eradealz/Screen/Login/login.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:eradealz/Screen//Forgot Password/Progress_dialog.dart';

class ResetPassScreen extends StatefulWidget {
  final String uid;

  ResetPassScreen({this.uid});

  @override
  _ResetPassScreenState createState() => _ResetPassScreenState();
}

class _ResetPassScreenState extends State<ResetPassScreen> {
  ProgressDialog progressDialog;

  final newpasswordcontroller = new TextEditingController();
  final confirmpasswordcontroller = new TextEditingController();

  final key = GlobalKey<FormState>();

  void checkNetwork() {
    updatePassword(widget.uid, newpasswordcontroller.text.toString(),
        confirmpasswordcontroller.text.toString());
  }

  void updatePassword(uid, String newpassword, String confirmpassword) async {
    progressDialog.show(
      'Updating...',
    );

    var map = new Map<String, String>();
    map['id'] = uid;
    map['password'] = newpassword;
    map['confirm'] = confirmpassword;
    String newpass = newpasswordcontroller.text;
    String confpass = confirmpasswordcontroller.text;

    var uri = await http.get("https://eradealz.com/api/password_reset.php?" +
        "id=" +
        widget.uid +
        "&password=" +
        newpass +
        "&confirm=" +
        confpass);
    var response = await ResetpassApi.fromJson(jsonDecode(uri.body));

    progressDialog..hide(context);
    if (response.message == "Password Updated") {
      Fluttertoast.showToast(
          msg: "Password Changed Successfully", textColor: Colors.white);

      Navigator.of(context).pushAndRemoveUntil(
          CustomPageRoute(child: LoginScreen()),
          (Route<dynamic> route) => false);
    } else if (response.message == "Password Mismathes..") {
      Fluttertoast.showToast(msg: 'Password mismache please check');
    } else {
      Fluttertoast.showToast(msg: 'Update Failed');
    }
  }

  @override
  Widget build(BuildContext context) {
    progressDialog = new ProgressDialog(context, ProgressDialogType.Normal);
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Form(
        key: key,
        child: ListView(
          //mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: size.height * 0.03),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Image.asset(
                  "images/logo.png",
                  height: 80,
                  width: 160,
                ),
              ],
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                "Reset\nPassword",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  color: Colors.grey.shade700,
                ),
                textAlign: TextAlign.left,
              ),
            ),
            SizedBox(height: size.height * 0.09),
            Padding(
              padding: const EdgeInsets.only(left: 15),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(width: size.width * 0.02),
                  Icon(
                    Icons.lock,
                    color: Colors.black26,
                    size: 27,
                  ),
                  SizedBox(width: size.width * 0.05),
                  Container(
                    height: 30,
                    width: 250,
                    child: TextFormField(
                      controller: newpasswordcontroller,
                      obscureText: false,
                      validator: (value) {
                        if (value.isEmpty) {
                          return "pleace enter your new password";
                        }
                        return null;
                      },
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                          hintText: "New Password",
                          hintStyle: TextStyle(color: Colors.black87)),
                    ),
                  )
                ],
              ),
            ),
            SizedBox(height: size.height * 0.06),
            Padding(
              padding: const EdgeInsets.only(left: 15),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(width: size.width * 0.02),
                  Icon(
                    Icons.lock,
                    color: Colors.black26,
                    size: 27,
                  ),
                  SizedBox(width: size.width * 0.05),
                  Container(
                    height: 30,
                    width: 250,
                    child: TextFormField(
                      controller: confirmpasswordcontroller,
                      obscureText: false,
                      validator: (value) {
                        if (value.isEmpty) {
                          return "pleace confirm your password";
                        }
                        return null;
                      },
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        hintText: "Confirm Password",
                        hintStyle: TextStyle(color: Colors.black87),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: size.height * 0.07),
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 20.0, horizontal: 30),
              child: SizedBox(
                height: 50, //height of button
                //width of button
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Color(0xFFec1c24),
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    padding: EdgeInsets.all(10),
                  ),
                  onPressed: () {
                    if (key.currentState.validate()) {
                      checkNetwork();
                    }
                  },
                  child: Text(
                    "Submit",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
