import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';

class work extends StatefulWidget {
  const work({Key key}) : super(key: key);

  @override
  _workState createState() => _workState();
}

class _workState extends State<work> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
          automaticallyImplyLeading: true,
          iconTheme: IconThemeData(color: Colors.black),
          backgroundColor: Colors.white,
          title: Text(
            'How It Works',
            style: appBarStyle,
          )),
      body: ListView(
        children: [
          Container(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: size.height * 0.02),
                  Text(
                    "* Buy any of our product through store, Website, Mobile Application or Instagram.",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* Get your free Raffle coupons corresponding to the purchase.",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* For emaple: If you buy any product from us you will get a raffle coupon to enter in our active campaigns.",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* Customer will get the raffle coupon along with purchased product.",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* Each raffle coupon will have the unique number with the customer details",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* Raffle draw will be conducted as per the information we mentioned in our website",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* Raffle draw event will be conducted in our head office (BENGALURU) with Live telecast in all Eradealz social media platforms.",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* Winner of the Raffle draw can collect the Price instantly.",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* Price will only be given to person who made the purchase",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* If the winner is not present at the raffle draw event, our managment will contact you from the event and will take the necessary steps to deliver the prize.",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* Eradeals would never ask for your bank details, OTP or any charges to claim the prices",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.2,
                    ),
                  ),
                  SizedBox(height: size.height * 0.01),
                  Text(
                    "* We are conducting the raffle draw to only increase the consumer engagement in products",
                    textAlign: TextAlign.justify,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  SizedBox(height: size.height * 0.06),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
