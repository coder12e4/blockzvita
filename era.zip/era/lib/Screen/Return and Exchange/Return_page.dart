import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';

class Return extends StatefulWidget {
  const Return({Key key}) : super(key: key);

  @override
  _ReturnState createState() => _ReturnState();
}

class _ReturnState extends State<Return> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          'Return and Exchange',
          style: appBarStyle,
        ),
      ),
      body: ListView(
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 20),
            child: Container(
              decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "To start the return process for your order, follow these steps:",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 15,
                      ),
                      textAlign: TextAlign.justify,
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "Email Address/Phone Number :",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "Order Number :",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "Start",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "• Enter your order number and email address in the fields above and click Start",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "• Follow the instructions and select the items you want to return, please ensure to attach a photo of the recieved item clearly showing the damaged or concerned area.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	Please allow us 2-3 working days to look into your request",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	You will get a confirmation email with the shipping guidelinesonce the return request is approved",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	Refunds once initiated will take 8-10 workings days to reflect in your account",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	If a wrong product is sent back to us by the customer, Eradealz will not accept the return exchange.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.04),
                    Text(
                      "What items are returnable?",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	All items except face masks, sunglasses, t-shirts, keychains, free gifts & promotional items are returnable and exchangeable.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	All items must be returned in their original condition with our box/packaging/ tags, as delivered to you, if a package is recieved without any of the above no refund will be initiated.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	All returns and exchanges initiated because of any reason other than damaged/wrong products shipped by us, will have to be returned and shipped by you, Eradealz will not bare the return charges.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	We do not accept a returned item that’s worn, damaged, washed or altered in any way.",
                     textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	Eradealz may reject the return request if the items are not returned according to the policy mentioned.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "* Please note: Face masks, Sunglasses, T-shirts, Keychains, Free gifts & promotional items are not returnable and exchangeable!",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.02),
                    Text(
                      "Are there any charges for return?",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	Not if it's Eradealz fault. Otherwise Rs.150.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	Original shipping charges is non-refundable",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	You can ship the return via your own courier if it is cheaper",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.04),
                    Text(
                      "How soon will I get my refund?",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.01),
                    Text(
                      "•	If you are approved, then your refund will be processed, and a credit will automatically be applied as per the original form of payment, within 7 working days.",
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: size.height * 0.06),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}


// To start the return process for your order, follow these steps:


// Email Address / Phone Number:

// Order Number:

// Start
// How do I return?
// •	Enter your order number and email address in the fields above and click Start
// •	Follow the instructions and select the items you want to return, please ensure to attach a photo of the recieved item clearly showing the damaged or concerned area.
// •	Please allow us 2-3 working days to look into your request
// •	You will get a confirmation email with the shipping guidelines once the return request is approved
// •	Refunds once initiated will take 8-10 workings days to reflect in your account
// •	If a wrong product is sent back to us by the customer, Eradealz will not accept the return / exchange.

// What items are returnable?
// You can return your items within 7 days of receipt of your shipment.
// •	All items except face masks, sunglasses, t-shirts, keychains, free gifts & promotional items are returnable and exchangeable.
// •	All items must be returned in their original condition with our box/packaging/ tags, as delivered to you, if a package is recieved without any of the above no refund will be initiated.
// •	All returns and exchanges initiated because of any reason other than damaged/wrong products shipped by us, will have to be returned and shipped by you, Eradealz will not bare the return charges.
// •	We do not accept a returned item that’s worn, damaged, washed or altered in any way.
// •	Eradealz may reject the return request if the items are not returned according to the policy mentioned.
// *Please note: Face masks, Sunglasses, T-shirts, Keychains, Free gifts & promotional items are not returnable and exchangeable!
// Are there any charges for return?
// •	Not if it's Eradealz fault. Otherwise Rs.150.
// •	Original shipping charges is non-refundable
// •	You can ship the return via your own courier if it is cheaper

// How soon will I get my refund?
// •	Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund
// •	If you are approved, then your refund will be processed, and a credit will automatically be applied as per the original form of payment, within 7 working days.
