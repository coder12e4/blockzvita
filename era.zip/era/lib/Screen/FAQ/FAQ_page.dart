import 'dart:convert';

import 'package:eradealz/Model/Faq_Class.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Faq extends StatefulWidget {
  const Faq({Key key}) : super(key: key);

  @override
  _FaqState createState() => _FaqState();
}

class _FaqState extends State<Faq> {
  Future<FAq> getdata() async {
    String url = "https://eradealz.com/api/faq.php";

    var responce = await http.get(url);
    if (responce.statusCode == 200) {
      print("Success");

      return FAq.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        backgroundColor: Colors.white,
        title: Text(
          'FAQs',
          style: appBarStyle,
        ),
      ),
      body: ListView(
        shrinkWrap: true,
        children: [
          FutureBuilder(
              future: getdata(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  List<Item> arr = snapshot.data.items;
                  return ListView.separated(
                    physics: BouncingScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: arr.length,
                    separatorBuilder: (context, index) => Divider(),
                    itemBuilder: (BuildContext context, int index) {
                      return ExpansionTile(
                        collapsedTextColor: Colors.black,
                        title: Text(
                          arr[index].question,
                        ),
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                              left: 16,
                              right: 16,
                              bottom: 16,
                            ),
                            child: Text(
                              arr[index].answer,
                              textAlign: TextAlign.justify,
                              style: TextStyle(
                                height: 1.2,
                              ),
                            ),
                          ),
                        ],
                        backgroundColor: Colors.grey[50],
                        expandedAlignment: Alignment.bottomLeft,
                        textColor: Colors.red,
                      );
                    },
                  );
                } else {
                  return Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.35,
                      ),
                      Center(child: Loading()),
                    ],
                  );
                }
              })
        ],
      ),
    );
  }
}
