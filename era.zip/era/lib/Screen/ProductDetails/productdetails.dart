import 'dart:convert';
import 'package:eradealz/Model/AddtoCart_Class.dart';
import 'package:eradealz/Model/Color_Class.dart';
import 'package:eradealz/Model/Productdetails_Class.dart';
import 'package:eradealz/Model/Size_Class.dart';
import 'package:eradealz/Screen/Cart/Cartpage.dart';
import 'package:eradealz/Screen/ProductDetails/pro_details.dart';
import 'package:eradealz/Widgets/Badge.dart';
import 'package:eradealz/Widgets/custom_page_route.dart';
import 'package:eradealz/Widgets/loading.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';

class ProductDetails extends StatefulWidget {
  String pid, oid;

  ProductDetails({Key key, this.pid, this.oid});

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

var refreshKey=GlobalKey<RefreshIndicatorState>();

class _ProductDetailsState extends State<ProductDetails> {
  final _key = GlobalKey<ScaffoldState>();
  bool exists = false;
  bool itsback = true;
  String selectedcolor, selectedsize;

  Future<ColorApi> getcolor() async {
    String url = "https://eradealz.com/api/color.php?" +
        "product_id=" +
        widget.pid +
        "&" +
        "offer_id=" +
        widget.oid;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print("Color Success");

      return ColorApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  Future<SizerApi> getsize() async {
    String url = "https://eradealz.com/api/size.php?" +
        "product_id=" +
        widget.pid +
        "&" +
        "offer_id=" +
        widget.oid;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print("Size Success");

      return SizerApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  Future<AddtocartApi> addtocart() async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');

    String url = "https://eradealz.com/api/add_cart.php?" +
        "product_id=" +
        widget.pid.toString() +
        "&" +
        "offer_id=" +
        widget.oid.toString() +
        "&" +
        "color=" +
        selectedcolor.toString() +
        "&" +
        "size=" +
        selectedsize.toString() +
        "&" +
        "id=" +
        userid;

    var Uri = await http.get(url);
    var response = await AddtocartApi.fromJson(jsonDecode(Uri.body));

    if (response.error == false)
    {
      print("add to cart success");
      return response;
    }
    else {
      print("add to cart failed");

      print(response.message);
    }
  }

  Future<Productdetails> pdetails() async {
    String url =
        "https://eradealz.com/api/fetch_product_details.php?" +
            "product_id" +
            "=" +
            widget.pid +
            "&" +
            "offer_id" +
            "=" +
            widget.oid;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print("details success");

      return Productdetails.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    pdetails();
    getcolor();
    getsize();
  }

  final CarouselController _controller = CarouselController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      key: _key,
      appBar: AppBar(
        automaticallyImplyLeading: true,
        iconTheme: IconThemeData(color: Colors.black),
        title: Container(
          child: Image.asset(
            "images/logo2.png",
            height: 48,
            width: 140,
          ),
        ),
        backgroundColor: Colors.white,
        centerTitle: true,
        actions: [
          Appbarbadge(),
        ],
      ),
      body: RefreshIndicator(
        key: refreshKey,
        onRefresh: refreshList,
        child: ListView(
          shrinkWrap: true,
          physics: BouncingScrollPhysics(),
          children: [
            FutureBuilder(
                future: pdetails(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    List<Item> arr = snapshot.data.items;
                    return ListView.builder(
                        itemCount: arr.length,
                        shrinkWrap: true,
                        physics: BouncingScrollPhysics(),
                        itemBuilder: (context, index) {
                          return Column(
                            children: [
                              Stack(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: CarouselSlider(
                                      items: [
                                        Container(
                                          child:  CachedNetworkImage(
                                            imageUrl: arr[index].photo.toString(),
                                            fit: BoxFit.fill,
                                            placeholder: (context, url) => Shimmer.fromColors(
                                              baseColor: Colors.grey.shade200,
                                              highlightColor: Colors.grey.shade50,
                                              child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(1),
                                                  child: Container(
                                                    color: Colors.grey.shade100,
                                                  )),
                                            ),
                                            errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                                          ),
                                          margin: EdgeInsets.all(6.0),
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadius.circular(8.0),
                                          ),
                                        ),
                                        Container(
                                          child: CachedNetworkImage(
                                            imageUrl: arr[index].photo1.toString(),
                                            fit: BoxFit.fill,
                                            placeholder: (context, url) => Shimmer.fromColors(
                                              baseColor: Colors.grey.shade200,
                                              highlightColor: Colors.grey.shade50,
                                              child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(1),
                                                  child: Container(
                                                    color: Colors.grey.shade100,
                                                  )),
                                            ),
                                            errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                                          ),
                                          margin: EdgeInsets.all(6.0),
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadius.circular(8.0),
                                          ),
                                        ),
                                        Container(
                                          child: CachedNetworkImage(
                                            imageUrl: arr[index].photo2.toString(),
                                            fit: BoxFit.fill,
                                            placeholder: (context, url) => Shimmer.fromColors(
                                              baseColor: Colors.grey.shade200,
                                              highlightColor: Colors.grey.shade50,
                                              child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(1),
                                                  child: Container(
                                                    color: Colors.grey.shade100,
                                                  )),
                                            ),
                                            errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                                          ),
                                          margin: EdgeInsets.all(6.0),
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadius.circular(8.0),
                                          ),
                                        ),
                                        Container(
                                          child: CachedNetworkImage(
                                            imageUrl: arr[index].photo3.toString(),
                                            fit: BoxFit.fill,
                                            placeholder: (context, url) => Shimmer.fromColors(
                                              baseColor: Colors.grey.shade200,
                                              highlightColor: Colors.grey.shade50,
                                              child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(1),
                                                  child: Container(
                                                    color: Colors.grey.shade100,
                                                  )),
                                            ),
                                            errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                                          ),
                                          margin: EdgeInsets.all(6.0),
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadius.circular(8.0),
                                          ),
                                        ),
                                        Container(
                                          child: CachedNetworkImage(
                                            imageUrl: arr[index].photo4.toString(),
                                            fit: BoxFit.fill,
                                            placeholder: (context, url) => Shimmer.fromColors(
                                              baseColor: Colors.grey.shade200,
                                              highlightColor: Colors.grey.shade50,
                                              child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(1),
                                                  child: Container(
                                                    color: Colors.grey.shade100,
                                                  )),
                                            ),
                                            errorWidget: (context, url, error) => Image.asset("images/ina.jpg",fit: BoxFit.fill,),
                                          ),
                                          margin: EdgeInsets.all(6.0),
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadius.circular(8.0),
                                          ),
                                        ),
                                      ],
                                      options: CarouselOptions(
                                        height: 225,
                                        enlargeCenterPage: true,
                                        autoPlay: false,
                                        aspectRatio: 1.0,
                                        viewportFraction: 1,
                                        enableInfiniteScroll: false,
                                      ),
                                      carouselController: _controller,
                                    ),
                                  ),
                                  Positioned(
                                    top: 100,
                                    child: IconButton(
                                      icon: Icon(
                                        Icons.arrow_back_ios,
                                        color: Colors.grey.shade600,
                                      ),
                                      onPressed: () {
                                        _controller.previousPage();
                                      },
                                    ),
                                  ),
                                  Positioned(
                                    top: 100,
                                    left: MediaQuery.of(context).size.width - 50,
                                    child: IconButton(
                                      icon: Icon(
                                        Icons.arrow_forward_ios,
                                        color: Colors.grey.shade600,
                                      ),
                                      onPressed: () {
                                        _controller.nextPage();
                                      },
                                    ),
                                  ),
                                ],
                              ),

                              Container(
                                padding: EdgeInsets.fromLTRB(25, 15, 25, 15),
                                child: Column(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      arr[index].name,
                                      style: TextStyle(
                                        color: Colors.black87,
                                        fontSize: 18.0,
                                        fontWeight: FontWeight.bold,
                                      ),
                                      textAlign: TextAlign.left,
                                    ),
                                    SizedBox(height: 5.0),
                                    Row(
                                      children: [
                                        Text(
                                          'INR ' + arr[index].price,
                                          style: TextStyle(
                                            color: Colors.black87,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16.0,
                                          ),
                                        ),
                                        SizedBox(width: 10.0),
                                        Container(
                                          decoration: BoxDecoration(
                                            borderRadius:
                                            BorderRadius.circular(17),
                                            color: Colors.teal.shade300,
                                          ),
                                          child: Center(
                                            child: Padding(
                                              padding: const EdgeInsets.all(5),
                                              child: Text(
                                                arr[index].entries + " Enteries",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: size.height * 0.01),
                                    Divider(
                                      color: Colors.grey[300],
                                    ),
                                    SizedBox(height: size.height * 0.01),
                                    //Avilability
                                    Row(
                                      children: [
                                        Text(
                                          'Availability:',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 16.0,
                                          ),
                                        ),
                                        SizedBox(width: size.width * 0.02),
                                        Text(
                                          arr[index].availableStock,
                                          style: TextStyle(
                                            color: Colors.teal.shade300,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: size.height * 0.01),
                                    //Get a chance to win
                                    Row(
                                      children: [
                                        Text(
                                          'Get a chance to win:',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 16.0,
                                          ),
                                        ),
                                        SizedBox(width: size.width * 0.02),
                                        Text(
                                          arr[index].offerName,
                                          style: TextStyle(
                                            color: Colors.teal.shade300,
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),

                              SizedBox(height: size.height * 0.02),

                              ///Color and size api call

                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Color:",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16),
                                      ),
                                      SizedBox(
                                        height: size.height * 0.01,
                                      ),
                                      FutureBuilder(
                                          future: getcolor(),
                                          builder: (context, snapshot) {
                                            if (snapshot.hasData) {
                                              List<Citem> arr =
                                                  snapshot.data.citems;
                                              return ClipRRect(
                                                borderRadius:
                                                BorderRadius.circular(6),
                                                child: Container(
                                                  height: size.height * 0.06,
                                                  width: size.width * 0.43,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: Colors.black54),
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          7),
                                                      color: Colors.white),
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets.all(8.0),
                                                    child: DropdownButton(
                                                        value: selectedcolor,
                                                        isExpanded: true,
                                                        underline: Container(),
                                                        hint: Text(
                                                          'Choose color',
                                                          style: TextStyle(),
                                                        ),
                                                        items: [
                                                          for (var i = 0;
                                                          i < arr.length;
                                                          i++)
                                                            DropdownMenuItem(
                                                              child: Text(
                                                                  arr[i].color),
                                                              value: arr[i].color,
                                                            )
                                                        ],
                                                        onChanged: (value) {
                                                          setState(() {
                                                            selectedcolor = value;
                                                          });
                                                        }),
                                                  ),
                                                ),
                                              );
                                            } else {
                                              return ClipRRect(
                                                borderRadius:
                                                BorderRadius.circular(6),
                                                child: Container(
                                                  height: size.height * 0.06,
                                                  width: size.width * 0.43,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: Colors.black54),
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          7),
                                                      color: Colors.white),
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets.all(8.0),
                                                    child: DropdownButton(
                                                      isExpanded: true,
                                                      underline: Container(),
                                                      hint: Text(
                                                        'Choose color',
                                                        style: TextStyle(),
                                                      ),
                                                      items: [],
                                                    ),
                                                  ),
                                                ),
                                              );
                                            }
                                          }),
                                    ],
                                  ),
                                  SizedBox(width: size.width * 0.03),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Size:",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16),
                                      ),
                                      SizedBox(
                                        height: size.height * 0.01,
                                      ),
                                      FutureBuilder(
                                          future: getsize(),
                                          builder: (context, snapshot) {
                                            if (snapshot.hasData) {
                                              List<Sitem> arr2 =
                                                  snapshot.data.sitems;
                                              return ClipRRect(
                                                borderRadius:
                                                BorderRadius.circular(6),
                                                child: Container(
                                                  height: size.height * 0.06,
                                                  width: size.width * 0.43,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: Colors.black54),
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          7),
                                                      color: Colors.white),
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets.all(8.0),
                                                    child: DropdownButton(
                                                        value: selectedsize,
                                                        isExpanded: true,
                                                        underline: Container(),
                                                        hint: Text(
                                                          'Choose size',
                                                          style: TextStyle(),
                                                        ),
                                                        items: [
                                                          for (var i = 0;
                                                          i < arr2.length;
                                                          i++)
                                                            DropdownMenuItem(
                                                              child: Text(
                                                                  arr2[i].size),
                                                              value: arr2[i].size,
                                                            )
                                                        ],
                                                        onChanged: (value) {
                                                          setState(() {
                                                            selectedsize =
                                                                value;
                                                          });
                                                        }),
                                                  ),
                                                ),
                                              );
                                            } else {
                                              return ClipRRect(
                                                borderRadius:
                                                BorderRadius.circular(6),
                                                child: Container(
                                                  height: size.height * 0.06,
                                                  width: size.width * 0.43,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: Colors.black54),
                                                      borderRadius:
                                                      BorderRadius.circular(
                                                          7),
                                                      color: Colors.white),
                                                  child: Padding(
                                                    padding:
                                                    const EdgeInsets.all(8.0),
                                                    child: DropdownButton(
                                                      isExpanded: true,
                                                      underline: Container(),
                                                      hint: Text(
                                                        'Choose size',
                                                        style: TextStyle(),
                                                      ),
                                                      items: [],
                                                    ),
                                                  ),
                                                ),
                                              );
                                            }
                                          }),
                                    ],
                                  ),
                                ],
                              ),

                              SizedBox(height: size.height * 0.04),
                              //Product details
                              ProDetails(
                                desc: arr[index].description,
                              ),

                              //button
                            ],
                          );
                        });
                  } else {
                    return Column(
                      children: [
                        SizedBox(
                          height: MediaQuery.of(context).size.height * 0.38,
                        ),
                        Center(child: Loading()),
                      ],
                    );
                  }
                }),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        height: 48,
        width: MediaQuery.of(context).size.width,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: exists
                  ? GestureDetector(
                onTap: () {
                  setState(() {
                    exists = false;
                  });
                  Navigator.push(
                      context,
                      CustomPageRoute(
                          child: Cart_Page()));
                },
                child: Container(
                    height: double.infinity,
                    color: Colors.grey.shade100,
                    child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "GO TO CART",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(
                              width: 2,
                            ),
                            Icon(
                              EvaIcons.shoppingCart,
                              size: 23,
                            )
                          ],
                        ))),
              )
                  : GestureDetector(
                onTap: () {


                  if(selectedcolor != null){

                    if(selectedsize != null)
                    {
                      setState(() {
                        exists = true;
                      });
                      addtocart();
                    }
                    else
                    {
                      _key.currentState.showSnackBar(SnackBar(
                          backgroundColor: Colors.black,
                          content: Text(
                            "Select a size",
                            style: TextStyle(color: Colors.white),
                          )));

                    }

                  }
                  else
                  {

                    _key.currentState.showSnackBar(SnackBar(
                        backgroundColor: Colors.black,
                        content: Text(
                          "Select a color",
                          style: TextStyle(color: Colors.white),
                        )));

                  }


                },
                child: Container(
                    height: double.infinity,
                    color: Colors.grey.shade100,
                    child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "ADD TO CART",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(
                              width: 2,
                            ),
                            Icon(
                              EvaIcons.shoppingCart,
                              size: 23,
                            )
                          ],
                        ))),
              ),
            ),
            Expanded(
                child: GestureDetector(
                  onTap: () {

                    if(selectedcolor != null){

                      if(selectedsize != null)
                      {
                        addtocart();
                        Navigator.push(
                            context,
                            CustomPageRoute(
                                child: Cart_Page()));
                        setState(() {

                        });
                      }
                      else
                      {
                        _key.currentState.showSnackBar(SnackBar(
                            backgroundColor: Colors.black,
                            content: Text(
                              "Select a size",
                              style: TextStyle(color: Colors.white),
                            )));

                      }

                    }
                    else
                    {

                      _key.currentState.showSnackBar(SnackBar(
                          backgroundColor: Colors.black,
                          content: Text(
                            "Select a color",
                            style: TextStyle(color: Colors.white),
                          )));

                    }

                  },
                  child: Container(
                      height: double.infinity,
                      color: Color(0xFFec1c24),
                      child: Center(
                          child: Text(
                            "BUY NOW",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, color: Colors.white),
                          ))),
                ))
          ],
        ),
      ),
    );
  }
  Future<void> refreshList() async{
    refreshKey.currentState.show(atTop: false);
    await Future.delayed(Duration(seconds: 2));
    setState(() {
      getcolor();
      getsize();
      pdetails();
    });
    return null;
  }
}

