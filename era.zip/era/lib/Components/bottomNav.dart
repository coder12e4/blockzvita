import 'package:eradealz/Screen/CurrentCapaign/Current_campagns.dart';
import 'package:eradealz/Screen/PastWinner/Past_winner.dart';
import 'package:eradealz/Screen/Profile/Profile_page.dart';
import 'package:eradealz/Screen/Refer/refer.dart';
import 'package:flutter/material.dart';
import '../Screen/Home/Home_page.dart';
import 'package:convex_bottom_bar/convex_bottom_bar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class BottomNav extends StatefulWidget {
  //const BottomNav({Key key}) : super(key: key);

  @override
  _BottomNavState createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav> {
  int _selectedIndex = 0;

  void ontap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  List<Widget> kk = [
    Past(),
    campaigns(),
    Home(),
    Profile(),
    Refer(),
  ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _selectedIndex = 2;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        bottomNavigationBar: ConvexAppBar(
          height: 75,
          backgroundColor: Color(0xFFec1c24), 
          color: Colors.grey.shade300,
          items: [
            TabItem(
              icon: Icon(
                Icons.emoji_events_rounded,
                size: 30,
              ),
              title: '    Past\n Winners',
            ),
            TabItem(
              icon: Icon(
                Icons.campaign_rounded,
                size: 30,
              ),
              title: '    Current Campaigns',
            ),
            TabItem(
              icon: Icon(
                Icons.home_rounded,
                size: 30,
              ),
              title: '  Home',
            ),
            TabItem(
              icon: Icon(
                Icons.person_rounded,
                size: 30,
              ),
              title: '  Profile',
            ),
            TabItem(
              icon: Icon(
                FontAwesomeIcons.shareAlt,
                size: 23,
                color: Colors.black,
              ),
              title: 'Share',
            ),
          ],
          initialActiveIndex: _selectedIndex,
          onTap: ontap,
        ),
        body: kk[_selectedIndex],
      ),
    );
  }
}
