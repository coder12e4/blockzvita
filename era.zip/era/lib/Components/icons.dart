import 'package:flutter/widgets.dart';

class MyFlutterApp {
  MyFlutterApp._();

  static const _kFontFam = 'MyFlutterApp';
  static const String _kFontPkg = null;

  static const IconData bullhorn = IconData(0xe800, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData back = IconData(0xe801, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData edit = IconData(0xe803, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData award = IconData(0xe804, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData shopping_cart = IconData(0xf07a, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData trophy = IconData(0xf091, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData facebook = IconData(0xf09a, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData youtube = IconData(0xf167, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData instagram = IconData(0xf16d, fontFamily: _kFontFam, fontPackage: _kFontPkg);
  static const IconData user_alt = IconData(0xf406, fontFamily: _kFontFam, fontPackage: _kFontPkg);
}