import 'dart:convert';
import 'package:eradealz/Model/Totalprice_Class.dart';
import 'package:eradealz/Screen/Cart/Cartpage.dart';
import 'package:flutter/material.dart';
import 'package:badges/badges.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class Appbarbadge extends StatefulWidget {

  @override
  _AppbarbadgeState createState() => _AppbarbadgeState();
}

class _AppbarbadgeState extends State<Appbarbadge> {

  Future ncount;
  Future<TotalpriceApi> Total() async {
    final prefs = await SharedPreferences.getInstance();
    String userid = prefs.getString('userId');

    String url =
        "https://eradealz.com/api/cart_total.php?" +
            "id=" +
            userid;

    var responce = await http.get(url);

    if (responce.statusCode == 200) {
      print("Total price success");

      return TotalpriceApi.fromJson(jsonDecode(responce.body));
    } else {
      print("No Connection");
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    ncount=Total();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: ncount,
      builder: (context,snapshot) {
        ErrorWidget.builder = (FlutterErrorDetails details) => Container();
        List<TotalClass> arr = [];
        arr = snapshot.data.totalClass;
        return Badge(
          position: BadgePosition.topEnd(top: 10, end: 10),
          badgeContent: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              for (var i = 0; i < arr.length; i++)
                Text(
                  arr[i].count.toString(),
                  style: TextStyle(color: Colors.white, fontSize: 10),
                ),
            ],
          ),
          child: IconButton(
            icon: Icon(
              Icons.shopping_cart_outlined,
              color: Colors.black,
            ),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Cart_Page(),
                ),
              );
              setState(() {});
            },
          ),
        );
      },
    );
  }
}
