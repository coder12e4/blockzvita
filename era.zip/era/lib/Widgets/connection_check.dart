import 'package:eradealz/constant.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class ConnectionCheck extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Center(
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "No connection",
              style: TextStyle(
                fontSize: 20,
                color: eraMainTextColor,
              ),
            ),
            SizedBox(height: size.height * 0.01),
            Text(
              "Please check your internet connectivity\nand try again",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: eraTextColor,
                fontSize: 15,
              ),
            ),
            const SizedBox(height: 5),
            Container(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  onPrimary: Colors.white,
                  primary: eraPrimaryColor,
                ),
                child: Container(
                  margin: EdgeInsets.all(10),
                  child: Text(
                    "Retry",
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.white,
                    ),
                  ),
                ),
                onPressed: () {
                  
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
