import 'package:flutter/material.dart';

//app color theme
const eraPrimaryColor = Color(0xFFec1c24);
const eraBackgroundColor = Color(0xFFFAFAFA);

const eraMainTextColor = Color(0xFF303030);
const eraTextColor = Color(0xFF757575);

final appBarStyle = TextStyle(
  fontSize: 18,
  color: Colors.black,
  height: 1.5,
);

// Form Error
final RegExp emailValidatorRegExp = RegExp(r"^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[a-zA-Z]+");
const String eraEmailNullError = "Please Enter your email";
const String eraInvalidEmailError = "Please Enter Valid Email";
const String eraPassNullError = "Please Enter your password";
const String eraShortPassError = "Password is too short";
const String eraMatchPassError = "Passwords don't match";
const String eraNamelNullError = "Please Enter your name";
const String eraPhoneNumberNullError = "Please Enter your phone number";
const String eraAddressNullError = "Please Enter your address";
