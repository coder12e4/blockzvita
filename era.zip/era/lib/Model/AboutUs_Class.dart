// To parse this JSON data, do
//
//     final aboutUs = aboutUsFromJson(jsonString);

import 'dart:convert';

AboutUs aboutUsFromJson(String str) => AboutUs.fromJson(json.decode(str));

String aboutUsToJson(AboutUs data) => json.encode(data.toJson());

class AboutUs {
  AboutUs({
    this.items,
  });

  List<Item> items;

  factory AboutUs.fromJson(Map<String, dynamic> json) => AboutUs(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.about,
  });

  String id;
  String about;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    about: json["about"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "about": about,
  };
}
