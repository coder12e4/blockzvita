// To parse this JSON data, do
//
//     final sizerApi = sizerApiFromJson(jsonString);

import 'dart:convert';

SizerApi sizerApiFromJson(String str) => SizerApi.fromJson(json.decode(str));

String sizerApiToJson(SizerApi data) => json.encode(data.toJson());

class SizerApi {
  SizerApi({
    this.sitems,
  });

  List<Sitem> sitems;

  factory SizerApi.fromJson(Map<String, dynamic> json) => SizerApi(
    sitems: List<Sitem>.from(json["sitems"].map((x) => Sitem.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "sitems": List<dynamic>.from(sitems.map((x) => x.toJson())),
  };
}

class Sitem {
  Sitem({
    this.size,
  });

  String size;

  factory Sitem.fromJson(Map<String, dynamic> json) => Sitem(
    size: json["size"],
  );

  Map<String, dynamic> toJson() => {
    "size": size,
  };
}
