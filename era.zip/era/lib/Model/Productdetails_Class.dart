// To parse this JSON data, do
//
//     final productdetails = productdetailsFromJson(jsonString);

import 'dart:convert';

Productdetails productdetailsFromJson(String str) => Productdetails.fromJson(json.decode(str));

String productdetailsToJson(Productdetails data) => json.encode(data.toJson());

class Productdetails {
  Productdetails({
    this.items,
  });

  List<Item> items;

  factory Productdetails.fromJson(Map<String, dynamic> json) => Productdetails(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.name,
    this.catId,
    this.description,
    this.price,
    this.stock,
    this.entries,
    this.availableStock,
    this.color,
    this.size,
    this.photo,
    this.photo1,
    this.photo2,
    this.photo3,
    this.photo4,
    this.offerId,
    this.offerPhoto,
    this.offerFrom,
    this.offerTo,
    this.offerName,
    this.day,
  });

  String id;
  String name;
  String catId;
  String description;
  String price;
  String stock;
  String entries;
  String availableStock;
  String color;
  String size;
  String photo;
  String photo1;
  String photo2;
  String photo3;
  String photo4;
  String offerId;
  String offerPhoto;
  DateTime offerFrom;
  DateTime offerTo;
  String offerName;
  String day;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    name: json["name"],
    catId: json["cat_id"],
    description: json["description"],
    price: json["price"],
    stock: json["stock"],
    entries: json["entries"],
    availableStock: json["available_stock"],
    color: json["color"],
    size: json["size"],
    photo: json["photo"],
    photo1: json["photo1"],
    photo2: json["photo2"],
    photo3: json["photo3"],
    photo4: json["photo4"],
    offerId: json["offer_id"],
    offerPhoto: json["offer_photo"],
    offerFrom: DateTime.parse(json["offer_from"]),
    offerTo: DateTime.parse(json["offer_to"]),
    offerName: json["offer_name"],
    day: json["day"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "cat_id": catId,
    "description": description,
    "price": price,
    "stock": stock,
    "entries": entries,
    "available_stock": availableStock,
    "color": color,
    "size": size,
    "photo": photo,
    "photo1": photo1,
    "photo2": photo2,
    "photo3": photo3,
    "photo4": photo4,
    "offer_id": offerId,
    "offer_photo": offerPhoto,
    "offer_from": "${offerFrom.year.toString().padLeft(4, '0')}-${offerFrom.month.toString().padLeft(2, '0')}-${offerFrom.day.toString().padLeft(2, '0')}",
    "offer_to": "${offerTo.year.toString().padLeft(4, '0')}-${offerTo.month.toString().padLeft(2, '0')}-${offerTo.day.toString().padLeft(2, '0')}",
    "offer_name": offerName,
    "day": day,
  };
}
