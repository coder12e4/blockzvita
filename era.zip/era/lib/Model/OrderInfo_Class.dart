// To parse this JSON data, do
//
//     final orderinfoApi = orderinfoApiFromJson(jsonString);

import 'dart:convert';

OrderinfoApi orderinfoApiFromJson(String str) => OrderinfoApi.fromJson(json.decode(str));

String orderinfoApiToJson(OrderinfoApi data) => json.encode(data.toJson());

class OrderinfoApi {
  OrderinfoApi({
    this.items,
  });

  List<Item> items;

  factory OrderinfoApi.fromJson(Map<String, dynamic> json) => OrderinfoApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.orderinfo,
  });

  String id;
  String orderinfo;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    orderinfo: json["orderinfo"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "orderinfo": orderinfo,
  };
}
