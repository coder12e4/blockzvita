// To parse this JSON data, do
//
//     final updatecartqtyApi = updatecartqtyApiFromJson(jsonString);

import 'dart:convert';

UpdatecartqtyApi updatecartqtyApiFromJson(String str) => UpdatecartqtyApi.fromJson(json.decode(str));

String updatecartqtyApiToJson(UpdatecartqtyApi data) => json.encode(data.toJson());

class UpdatecartqtyApi {
  UpdatecartqtyApi({
    this.qitems,
  });

  List<Qitem> qitems;

  factory UpdatecartqtyApi.fromJson(Map<String, dynamic> json) => UpdatecartqtyApi(
    qitems: List<Qitem>.from(json["qitems"].map((x) => Qitem.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "qitems": List<dynamic>.from(qitems.map((x) => x.toJson())),
  };
}

class Qitem {
  Qitem({
    this.messsage,
    this.userId,
  });

  String messsage;
  String userId;

  factory Qitem.fromJson(Map<String, dynamic> json) => Qitem(
    messsage: json["messsage"],
    userId: json["user_id"],
  );

  Map<String, dynamic> toJson() => {
    "messsage": messsage,
    "user_id": userId,
  };
}
