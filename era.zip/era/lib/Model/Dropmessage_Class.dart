// To parse this JSON data, do
//
//     final feedbackApi = feedbackApiFromJson(jsonString);

import 'dart:convert';

FeedbackApi feedbackApiFromJson(String str) => FeedbackApi.fromJson(json.decode(str));

String feedbackApiToJson(FeedbackApi data) => json.encode(data.toJson());

class FeedbackApi {
  FeedbackApi({
    this.message,
    this.error,
  });


  String message;
  bool error;

  factory FeedbackApi.fromJson(Map<String, dynamic> json) => FeedbackApi(
    message: json["message"],
    error: json["error"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "error": error,
  };
}
