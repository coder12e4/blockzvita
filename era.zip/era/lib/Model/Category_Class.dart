// To parse this JSON data, do
//
//     final categoryApi = categoryApiFromJson(jsonString);

import 'dart:convert';

CategoryApi categoryApiFromJson(String str) => CategoryApi.fromJson(json.decode(str));

String categoryApiToJson(CategoryApi data) => json.encode(data.toJson());

class CategoryApi {
  CategoryApi({
    this.items,
  });

  List<Item> items;

  factory CategoryApi.fromJson(Map<String, dynamic> json) => CategoryApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.name,
    this.photo,
  });

  String id;
  String name;
  String photo;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    name: json["name"],
    photo: json["photo"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "photo": photo,
  };
}
