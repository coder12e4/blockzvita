// To parse this JSON data, do
//
//     final updateaddressApi = updateaddressApiFromJson(jsonString);

import 'dart:convert';

UpdateaddressApi updateaddressApiFromJson(String str) => UpdateaddressApi.fromJson(json.decode(str));

String updateaddressApiToJson(UpdateaddressApi data) => json.encode(data.toJson());

class UpdateaddressApi {
  UpdateaddressApi({
    this.uitems,
  });

  List<Uitem> uitems;

  factory UpdateaddressApi.fromJson(Map<String, dynamic> json) => UpdateaddressApi(
    uitems: List<Uitem>.from(json["uitems"].map((x) => Uitem.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "uitems": List<dynamic>.from(uitems.map((x) => x.toJson())),
  };
}

class Uitem {
  Uitem({
    this.housename,
    this.streetno,
    this.area,
    this.city,
    this.country,
    this.pincode,
    this.state,
    this.phone,
  });

  String housename;
  String streetno;
  String area;
  String city;
  String country;
  String pincode;
  String state;
  String phone;

  factory Uitem.fromJson(Map<String, dynamic> json) => Uitem(
    housename: json["housename"],
    streetno: json["streetno"],
    area: json["area"],
    city: json["city"],
    country: json["country"],
    pincode: json["pincode"],
    state: json["state"],
    phone: json["phone"],
  );

  Map<String, dynamic> toJson() => {
    "housename": housename,
    "streetno": streetno,
    "area": area,
    "city": city,
    "country": country,
    "pincode": pincode,
    "state": state,
    "phone": phone,
  };
}
