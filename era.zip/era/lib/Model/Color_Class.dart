// To parse this JSON data, do
//
//     final colorApi = colorApiFromJson(jsonString);

import 'dart:convert';

ColorApi colorApiFromJson(String str) => ColorApi.fromJson(json.decode(str));

String colorApiToJson(ColorApi data) => json.encode(data.toJson());

class ColorApi {
  ColorApi({
    this.citems,
  });

  List<Citem> citems;

  factory ColorApi.fromJson(Map<String, dynamic> json) => ColorApi(
    citems: List<Citem>.from(json["citems"].map((x) => Citem.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "citems": List<dynamic>.from(citems.map((x) => x.toJson())),
  };
}

class Citem {
  Citem({
    this.color,
  });

  String color;

  factory Citem.fromJson(Map<String, dynamic> json) => Citem(
    color: json["color"],
  );

  Map<String, dynamic> toJson() => {
    "color": color,
  };
}
