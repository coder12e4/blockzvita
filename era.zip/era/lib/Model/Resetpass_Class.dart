// To parse this JSON data, do
//
//     final resetpassApi = resetpassApiFromJson(jsonString);

import 'dart:convert';

ResetpassApi resetpassApiFromJson(String str) => ResetpassApi.fromJson(json.decode(str));

String resetpassApiToJson(ResetpassApi data) => json.encode(data.toJson());

class ResetpassApi {
  ResetpassApi({
    this.message,
    this.id,
  });

  String message;
  String id;

  factory ResetpassApi.fromJson(Map<String, dynamic> json) => ResetpassApi(
    message: json["message"],
    id: json["id"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "id": id,
  };
}
