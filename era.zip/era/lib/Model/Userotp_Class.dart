// To parse this JSON data, do
//
//     final userotpApi = userotpApiFromJson(jsonString);

import 'dart:convert';

UserotpApi userotpApiFromJson(String str) => UserotpApi.fromJson(json.decode(str));

String userotpApiToJson(UserotpApi data) => json.encode(data.toJson());

class UserotpApi {
  UserotpApi({
    this.message,
    this.id,
  });

  String message;
  String id;

  factory UserotpApi.fromJson(Map<String, dynamic> json) => UserotpApi(
    message: json["message"],
    id: json["id"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "id": id,
  };
}
