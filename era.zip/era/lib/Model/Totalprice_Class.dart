// To parse this JSON data, do
//
//     final totalpriceApi = totalpriceApiFromJson(jsonString);

import 'dart:convert';

TotalpriceApi totalpriceApiFromJson(String str) => TotalpriceApi.fromJson(json.decode(str));

String totalpriceApiToJson(TotalpriceApi data) => json.encode(data.toJson());

class TotalpriceApi {
  TotalpriceApi({
    this.totalClass,
  });

  List<TotalClass> totalClass;

  factory TotalpriceApi.fromJson(Map<String, dynamic> json) => TotalpriceApi(
    totalClass: List<TotalClass>.from(json["total_class"].map((x) => TotalClass.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "total_class": List<dynamic>.from(totalClass.map((x) => x.toJson())),
  };
}

class TotalClass {
  TotalClass({
    this.count,
    this.totalPrice,
    this.totalEnt,
  });

  int count;
  int totalPrice;
  int totalEnt;

  factory TotalClass.fromJson(Map<String, dynamic> json) => TotalClass(
    count: json["count"],
    totalPrice: json["total_price"],
    totalEnt: json["total_ent"],
  );

  Map<String, dynamic> toJson() => {
    "count": count,
    "total_price": totalPrice,
    "total_ent": totalEnt,
  };
}
