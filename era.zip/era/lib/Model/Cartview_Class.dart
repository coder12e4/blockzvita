// To parse this JSON data, do
//
//     final cartviewApi = cartviewApiFromJson(jsonString);

import 'dart:convert';

CartviewApi cartviewApiFromJson(String str) => CartviewApi.fromJson(json.decode(str));

String cartviewApiToJson(CartviewApi data) => json.encode(data.toJson());

class CartviewApi {
  CartviewApi({
    this.items,
  });

  List<Item> items;

  factory CartviewApi.fromJson(Map<String, dynamic> json) => CartviewApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.photo,
    this.price,
    this.productName,
    this.color,
    this.size,
    this.quantity,
    this.userId,
    this.userName,
    this.email,
    this.cartId,
  });

  String photo;
  String price;
  String productName;
  String color;
  String size;
  String quantity;
  String userId;
  String userName;
  String email;
  String cartId;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    photo: json["photo"],
    price: json["price"],
    productName: json["product_name"],
    color: json["color"],
    size: json["size"],
    quantity: json["quantity"],
    userId: json["user_id"],
    userName: json["user_name"],
    email: json["email"],
    cartId: json["cart_id"],
  );

  Map<String, dynamic> toJson() => {
    "photo": photo,
    "price": price,
    "product_name": productName,
    "color": color,
    "size": size,
    "quantity": quantity,
    "user_id": userId,
    "user_name": userName,
    "email": email,
    "cart_id": cartId,
  };
}
