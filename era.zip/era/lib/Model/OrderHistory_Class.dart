// To parse this JSON data, do
//
//     final orderHistoryApi = orderHistoryApiFromJson(jsonString);

import 'dart:convert';

OrderHistoryApi orderHistoryApiFromJson(String str) => OrderHistoryApi.fromJson(json.decode(str));

String orderHistoryApiToJson(OrderHistoryApi data) => json.encode(data.toJson());

class OrderHistoryApi {
    OrderHistoryApi({
        this.items,
    });

    List<Item> items;

    factory OrderHistoryApi.fromJson(Map<String, dynamic> json) => OrderHistoryApi(
        items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "items": List<dynamic>.from(items.map((x) => x.toJson())),
    };
}

class Item {
    Item({
        this.purId,
        this.username,
        this.campaign,
        this.productName,
        this.quantity,
        this.amount,
        this.photo,
    });

    String purId;
    String username;
    String campaign;
    String productName;
    String quantity;
    String amount;
    String photo;

    factory Item.fromJson(Map<String, dynamic> json) => Item(
        purId: json["pur_id"],
        username: json["username"],
        campaign: json["campaign"],
        productName: json["product name"],
        quantity: json["quantity"],
        amount: json["amount"],
        photo: json["photo"],
    );

    Map<String, dynamic> toJson() => {
        "pur_id": purId,
        "username": usernameValues.reverse[username],
        "campaign": campaignValues.reverse[campaign],
        "product name": productNameValues.reverse[productName],
        "quantity": quantity,
        "amount": amount,
        "photo": photo,
    };
}

enum Campaign { SAMSUNG, IPHONE_12, CAR }

final campaignValues = EnumValues({
    "Car": Campaign.CAR,
    "IPHONE 12": Campaign.IPHONE_12,
    "Samsung": Campaign.SAMSUNG
});

enum ProductName { SAMPLE111, T_SHIRT, PRODUCT_NAME_T_SHIRT, CAP, HOODIE, BIKE10 }

final productNameValues = EnumValues({
    "bike10": ProductName.BIKE10,
    "Cap": ProductName.CAP,
    "HOODIE": ProductName.HOODIE,
    " T-Shirt": ProductName.PRODUCT_NAME_T_SHIRT,
    "sample111": ProductName.SAMPLE111,
    "T-SHIRT": ProductName.T_SHIRT
});

enum Username { JOHNSS1111 }

final usernameValues = EnumValues({
    "johnss1111": Username.JOHNSS1111
});

class EnumValues<T> {
    Map<String, T> map;
    Map<T, String> reverseMap;

    EnumValues(this.map);

    Map<T, String> get reverse {
        if (reverseMap == null) {
            reverseMap = map.map((k, v) => new MapEntry(v, k));
        }
        return reverseMap;
    }
}
