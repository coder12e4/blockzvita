// To parse this JSON data, do
//
//     final winnersdetailsApi = winnersdetailsApiFromJson(jsonString);

import 'dart:convert';

WinnersdetailsApi winnersdetailsApiFromJson(String str) => WinnersdetailsApi.fromJson(json.decode(str));

String winnersdetailsApiToJson(WinnersdetailsApi data) => json.encode(data.toJson());

class WinnersdetailsApi {
  WinnersdetailsApi({
    this.items,
  });

  List<Item> items;

  factory WinnersdetailsApi.fromJson(Map<String, dynamic> json) => WinnersdetailsApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.userName,
    this.raffleId,
    this.offer,
    this.time,
    this.winnerPhoto,
    this.winnerPhoto1,
    this.winnerPhoto2,
  });

  String id;
  String userName;
  String raffleId;
  String offer;
  DateTime time;
  String winnerPhoto;
  String winnerPhoto1;
  String winnerPhoto2;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    userName: json["user_name"],
    raffleId: json["raffle_id"],
    offer: json["offer"],
    time: DateTime.parse(json["time"]),
    winnerPhoto: json["winner_photo"],
    winnerPhoto1: json["winner_photo1"],
    winnerPhoto2: json["winner_photo2"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_name": userName,
    "raffle_id": raffleId,
    "offer": offer,
    "time": time.toIso8601String(),
    "winner_photo": winnerPhoto,
    "winner_photo1": winnerPhoto1,
    "winner_photo2": winnerPhoto2,
  };
}
