// To parse this JSON data, do
//
//     final addaddressApi = addaddressApiFromJson(jsonString);

import 'dart:convert';

AddaddressApi addaddressApiFromJson(String str) => AddaddressApi.fromJson(json.decode(str));

String addaddressApiToJson(AddaddressApi data) => json.encode(data.toJson());

class AddaddressApi {
    AddaddressApi({
        this.items,
        this.message,
        this.error,
    });

    List<dynamic> items;
    String message;
    bool error;

    factory AddaddressApi.fromJson(Map<String, dynamic> json) => AddaddressApi(
        items: List<dynamic>.from(json["items"].map((x) => x)),
        message: json["message"],
        error: json["error"],
    );

    Map<String, dynamic> toJson() => {
        "items": List<dynamic>.from(items.map((x) => x)),
        "message": message,
        "error": error,
    };
}
