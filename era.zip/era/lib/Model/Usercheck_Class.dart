// To parse this JSON data, do
//
//     final usercheckApi = usercheckApiFromJson(jsonString);

import 'dart:convert';

UsercheckApi usercheckApiFromJson(String str) => UsercheckApi.fromJson(json.decode(str));

String usercheckApiToJson(UsercheckApi data) => json.encode(data.toJson());

class UsercheckApi {
  UsercheckApi({
    this.message,
    this.id,
  });

  String message;
  String id;

  factory UsercheckApi.fromJson(Map<String, dynamic> json) => UsercheckApi(
    message: json["message"],
    id: json["id"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "id": id,
  };
}
