// To parse this JSON data, do
//
//     final signupApi = signupApiFromJson(jsonString);

import 'dart:convert';

SignupApi signupApiFromJson(String str) => SignupApi.fromJson(json.decode(str));

String signupApiToJson(SignupApi data) => json.encode(data.toJson());

class SignupApi {
  SignupApi({
    this.message,
    this.error,
  });

  String message;
  bool error;

  factory SignupApi.fromJson(Map<String, dynamic> json) => SignupApi(
    message: json["message"],
    error: json["error"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "error": error,
  };
}


