// To parse this JSON data, do
//
//     final pastwinnersApi = pastwinnersApiFromJson(jsonString);

import 'dart:convert';

PastwinnersApi pastwinnersApiFromJson(String str) => PastwinnersApi.fromJson(json.decode(str));

String pastwinnersApiToJson(PastwinnersApi data) => json.encode(data.toJson());

class PastwinnersApi {
  PastwinnersApi({
    this.items,
  });

  List<Item> items;

  factory PastwinnersApi.fromJson(Map<String, dynamic> json) => PastwinnersApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.userName,
    this.raffleId,
    this.offer,
    this.time,
    this.winnerPhoto,
  });

  String id;
  String userName;
  String raffleId;
  String offer;
  DateTime time;
  String winnerPhoto;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    userName: json["user_name"],
    raffleId: json["raffle_id"],
    offer: json["offer"],
    time: DateTime.parse(json["time"]),
    winnerPhoto: json["winner_photo"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_name": userName,
    "raffle_id": raffleId,
    "offer": offer,
    "time": time.toIso8601String(),
    "winner_photo": winnerPhoto,
  };
}
