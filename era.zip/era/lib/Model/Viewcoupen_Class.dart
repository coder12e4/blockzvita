// To parse this JSON data, do
//
//     final viewcouponApi = viewcouponApiFromJson(jsonString);

import 'dart:convert';

ViewcouponApi viewcouponApiFromJson(String str) => ViewcouponApi.fromJson(json.decode(str));

String viewcouponApiToJson(ViewcouponApi data) => json.encode(data.toJson());

class ViewcouponApi {
  ViewcouponApi({
    this.items,
  });

  List<Item> items;

  factory ViewcouponApi.fromJson(Map<String, dynamic> json) => ViewcouponApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.raffleId,
    this.username,
    this.campaign,
    this.productname,
  });

  String raffleId;
  String username;
  String campaign;
  String productname;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    raffleId: json["Raffle_id"],
    username: json["username"],
    campaign: json["campaign"],
    productname: json["productname"],
  );

  Map<String, dynamic> toJson() => {
    "Raffle_id": raffleId,
    "username": username,
    "campaign": campaign,
    "productname": productname,
  };
}
