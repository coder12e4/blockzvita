// To parse this JSON data, do
//
//     final privaci = privaciFromJson(jsonString);

import 'dart:convert';

Privaci privaciFromJson(String str) => Privaci.fromJson(json.decode(str));

String privaciToJson(Privaci data) => json.encode(data.toJson());

class Privaci {
  Privaci({
    this.items,
  });

  List<Item> items;

  factory Privaci.fromJson(Map<String, dynamic> json) => Privaci(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.privacy,
  });

  String id;
  String privacy;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    privacy: json["privacy"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "privacy": privacy,
  };
}
