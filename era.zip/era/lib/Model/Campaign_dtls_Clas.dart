// To parse this JSON data, do
//
//     final campaigndetailsApi = campaigndetailsApiFromJson(jsonString);

import 'dart:convert';

CampaigndetailsApi campaigndetailsApiFromJson(String str) => CampaigndetailsApi.fromJson(json.decode(str));

String campaigndetailsApiToJson(CampaigndetailsApi data) => json.encode(data.toJson());

class CampaigndetailsApi {
  CampaigndetailsApi({
    this.items,
  });

  List<Item> items;

  factory CampaigndetailsApi.fromJson(Map<String, dynamic> json) => CampaigndetailsApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.name,
    this.fromDate,
    this.description,
    this.toDate,
    this.offerPhoto,
    this.day,
  });

  String id;
  String name;
  DateTime fromDate;
  String description;
  DateTime toDate;
  String offerPhoto;
  String day;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    name: json["name"],
    fromDate: DateTime.parse(json["from_date"]),
    description: json["description"],
    toDate: DateTime.parse(json["to_date"]),
    offerPhoto: json["offer_photo"],
    day: json["day"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "from_date": "${fromDate.year.toString().padLeft(4, '0')}-${fromDate.month.toString().padLeft(2, '0')}-${fromDate.day.toString().padLeft(2, '0')}",
    "description": description,
    "to_date": "${toDate.year.toString().padLeft(4, '0')}-${toDate.month.toString().padLeft(2, '0')}-${toDate.day.toString().padLeft(2, '0')}",
    "offer_photo": offerPhoto,
    "day": day,
  };
}
