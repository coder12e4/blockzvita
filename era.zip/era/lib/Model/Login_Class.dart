// To parse this JSON data, do
//
//     final loginApi = loginApiFromJson(jsonString);

import 'dart:convert';

LoginApi loginApiFromJson(String str) => LoginApi.fromJson(json.decode(str));

String loginApiToJson(LoginApi data) => json.encode(data.toJson());

class LoginApi {
  LoginApi({
    this.items,
    this.message,
    this.error,
  });

  List<Item> items;
  String message;
  bool error;

  factory LoginApi.fromJson(Map<String, dynamic> json) => LoginApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
    message: json["message"],
    error: json["error"],
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
    "message": message,
    "error": error,
  };
}

class Item {
  Item({
    this.id,
    this.name,
    this.phone,
    this.email,
    this.referal,
  });

  String id;
  String name;
  String phone;
  String email;
  String referal;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    name: json["name"],
    phone: json["phone"],
    email: json["email"],
    referal: json["referal"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "phone": phone,
    "email": email,
    "referal": referal,
  };
}
