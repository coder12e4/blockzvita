// To parse this JSON data, do
//
//     final cartdeleteApi = cartdeleteApiFromJson(jsonString);

import 'dart:convert';

CartdeleteApi cartdeleteApiFromJson(String str) => CartdeleteApi.fromJson(json.decode(str));

String cartdeleteApiToJson(CartdeleteApi data) => json.encode(data.toJson());

class CartdeleteApi {
  CartdeleteApi({
    this.message,
  });

  String message;

  factory CartdeleteApi.fromJson(Map<String, dynamic> json) => CartdeleteApi(
    message: json["message"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
  };
}
