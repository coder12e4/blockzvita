// To parse this JSON data, do
//
//     final bannerApi = bannerApiFromJson(jsonString);

import 'dart:convert';

BannerApi bannerApiFromJson(String str) => BannerApi.fromJson(json.decode(str));

String bannerApiToJson(BannerApi data) => json.encode(data.toJson());

class BannerApi {
  BannerApi({
    this.items,
  });

  List<Item> items;

  factory BannerApi.fromJson(Map<String, dynamic> json) => BannerApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.catId,
    this.photo,
  });

  String id;
  String catId;
  String photo;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    catId: json["cat_id"],
    photo: json["photo"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "cat_id": catId,
    "photo": photo,
  };
}
