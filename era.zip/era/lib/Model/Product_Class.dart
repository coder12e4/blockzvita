// To parse this JSON data, do
//
//     final products = productsFromJson(jsonString);

import 'dart:convert';

Products productsFromJson(String str) => Products.fromJson(json.decode(str));

String productsToJson(Products data) => json.encode(data.toJson());

class Products {
  Products({
    this.items,
  });

  List<Item> items;

  factory Products.fromJson(Map<String, dynamic> json) => Products(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.name,
    this.catId,
    this.description,
    this.price,
    this.stock,
    this.entries,
    this.availableStock,
    this.color,
    this.size,
    this.photo1,
    this.photo,
    this.offerId,
    this.offerPhoto,
    this.offerFrom,
    this.offerTo,
    this.offerName,
    this.day,
  });

  String id;
  String name;
  String catId;
  String description;
  String price;
  String stock;
  String entries;
  String availableStock;
  String color;
  String size;
  String photo1;
  String photo;
  String offerId;
  String offerPhoto;
  DateTime offerFrom;
  DateTime offerTo;
  String offerName;
  Day day;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    name: json["name"],
    catId: json["cat_id"],
    description: json["description"],
    price: json["price"],
    stock: json["stock"],
    entries: json["entries"],
    availableStock: json["available_stock"],
    color: json["color"],
    size: json["size"],
    photo1: json["photo1"],
    photo: json["photo"],
    offerId: json["offer_id"],
    offerPhoto: json["offer_photo"],
    offerFrom: DateTime.parse(json["offer_from"]),
    offerTo: DateTime.parse(json["offer_to"]),
    offerName: json["offer_name"],
    day: dayValues.map[json["day"]],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "cat_id": catId,
    "description": description,
    "price": price,
    "stock": stock,
    "entries": entries,
    "available_stock": availableStock,
    "color": color,
    "size": size,
    "photo1": photo1,
    "photo": photo,
    "offer_id": offerId,
    "offer_photo": offerPhoto,
    "offer_from": "${offerFrom.year.toString().padLeft(4, '0')}-${offerFrom.month.toString().padLeft(2, '0')}-${offerFrom.day.toString().padLeft(2, '0')}",
    "offer_to": "${offerTo.year.toString().padLeft(4, '0')}-${offerTo.month.toString().padLeft(2, '0')}-${offerTo.day.toString().padLeft(2, '0')}",
    "offer_name": offerName,
    "day": dayValues.reverse[day],
  };
}

enum Day { DRAWDATE, THE_190721, AVAILABLE, THE_01022021 }

final dayValues = EnumValues({
  "available": Day.AVAILABLE,
  "drawdate": Day.DRAWDATE,
  "01/02/2021": Day.THE_01022021,
  "19/07/21": Day.THE_190721
});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
