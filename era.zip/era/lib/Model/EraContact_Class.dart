// To parse this JSON data, do
//
//     final contactApi = contactApiFromJson(jsonString);

import 'dart:convert';

ContactApi contactApiFromJson(String str) => ContactApi.fromJson(json.decode(str));

String contactApiToJson(ContactApi data) => json.encode(data.toJson());

class ContactApi {
  ContactApi({
    this.items,
  });

  List<Item> items;

  factory ContactApi.fromJson(Map<String, dynamic> json) => ContactApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.address,
    this.street,
    this.postal,
    this.country,
    this.email,
    this.phone,
  });

  String id;
  String address;
  String street;
  String postal;
  String country;
  String email;
  String phone;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    address: json["address"],
    street: json["street"],
    postal: json["postal"],
    country: json["country"],
    email: json["email"],
    phone: json["phone"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "address": address,
    "street": street,
    "postal": postal,
    "country": country,
    "email": email,
    "phone": phone,
  };
}
