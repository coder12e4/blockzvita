// To parse this JSON data, do
//
//     final fAq = fAqFromJson(jsonString);

import 'dart:convert';

FAq fAqFromJson(String str) => FAq.fromJson(json.decode(str));

String fAqToJson(FAq data) => json.encode(data.toJson());

class FAq {
  FAq({
    this.items,
  });

  List<Item> items;

  factory FAq.fromJson(Map<String, dynamic> json) => FAq(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.id,
    this.question,
    this.answer,
  });

  String id;
  String question;
  String answer;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    id: json["id"],
    question: json["question"],
    answer: json["answer"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "question": question,
    "answer": answer,
  };
}
