// To parse this JSON data, do
//
//     final addtocartApi = addtocartApiFromJson(jsonString);

import 'dart:convert';

AddtocartApi addtocartApiFromJson(String str) => AddtocartApi.fromJson(json.decode(str));

String addtocartApiToJson(AddtocartApi data) => json.encode(data.toJson());

class AddtocartApi {
  AddtocartApi({
    this.message,
    this.error,
  });

  String message;
  bool error;

  factory AddtocartApi.fromJson(Map<String, dynamic> json) => AddtocartApi(
    message: json["message"],
    error: json["error"],
  );

  Map<String, dynamic> toJson() => {
    "message": message,
    "error": error,
  };
}
