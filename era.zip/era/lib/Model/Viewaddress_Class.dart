// To parse this JSON data, do
//
//     final viewaddressApi = viewaddressApiFromJson(jsonString);

import 'dart:convert';

ViewaddressApi viewaddressApiFromJson(String str) => ViewaddressApi.fromJson(json.decode(str));

String viewaddressApiToJson(ViewaddressApi data) => json.encode(data.toJson());

class ViewaddressApi {
  ViewaddressApi({
    this.items,
  });

  List<Item> items;

  factory ViewaddressApi.fromJson(Map<String, dynamic> json) => ViewaddressApi(
    items: List<Item>.from(json["items"].map((x) => Item.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "items": List<dynamic>.from(items.map((x) => x.toJson())),
  };
}

class Item {
  Item({
    this.housename,
    this.streetno,
    this.area,
    this.city,
    this.country,
    this.pincode,
    this.state,
    this.phone,
  });

  String housename;
  String streetno;
  String area;
  String city;
  String country;
  String pincode;
  String state;
  String phone;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
    housename: json["housename"],
    streetno: json["streetno"],
    area: json["area"],
    city: json["city"],
    country: json["country"],
    pincode: json["pincode"],
    state: json["state"],
    phone: json["phone"],
  );

  Map<String, dynamic> toJson() => {
    "housename": housename,
    "streetno": streetno,
    "area": area,
    "city": city,
    "country": country,
    "pincode": pincode,
    "state": state,
    "phone": phone,
  };
}
